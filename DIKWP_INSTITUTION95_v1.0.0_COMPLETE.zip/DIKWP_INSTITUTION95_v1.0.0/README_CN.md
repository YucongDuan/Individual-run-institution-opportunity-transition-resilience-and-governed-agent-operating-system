# DIKWP-INSTITUTION95

## 个体机构化机会、转型与韧性操作系统

面向AI与Agent重组劳动、专业服务、组织边界和知识价格的未来，帮助高价值个体从“按时间出售知识”转向拥有资产、产品、受治理Agent岗位、现金组合、协议入口、伙伴网络和继任能力的微型机构。

### 当前演示

- 15项机构资产；
- 13项未来信号；
- 7个非同构世界模型；
- 13个候选机会；
- 6项组合配置；
- 9类Agent岗位；
- 180天转型计划；
- MCP只读参考子集、A2A Agent Card和回环OpenAPI；
- 自动外部行动、付款、身份和自我修改权限全部为0。

### 运行

```bash
python run.py doctor
python run.py demo --out outputs/demo
python run.py verify --out outputs/demo
```

或安装wheel：

```bash
pip install dikwp_institution95-1.0.0-py3-none-any.whl
institution95 demo --out outputs/demo
```

### 核心边界

机会分数不是收入预测；场景权重不是发生概率；示例财务不是所有者真实财务；接口未获得独立MCP/A2A一致性认证；AI透明清单不是法律意见或合规证书。

### 文档

- `docs/FULL_SYSTEM_REPORT_CN.md`
- `docs/FUTURE_SOCIAL_CHANGE_MAP_CN.md`
- `docs/BUSINESS_MODEL_AND_PRICING_CN.md`
- `docs/TRANSITION_PLAYBOOK_180_DAYS_CN.md`
- `docs/ARCHITECTURE_CN.md`
- `docs/SECURITY_GOVERNANCE_CN_EN.md`
- `docs/CLAIM_BOUNDARIES_CN_EN.md`

Apache-2.0 applies to the code. It does not transfer third-party content, patents, trademarks, personal identity, voice, private memory, endorsement, or official representation rights.
