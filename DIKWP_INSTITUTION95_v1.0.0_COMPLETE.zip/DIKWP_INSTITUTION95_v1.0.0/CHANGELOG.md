# Changelog

## 1.0.0 — 2026-09-01

- Initial open-source reference release of DIKWP-INSTITUTION95.
- Added future-signal ledger and seven-model scenario ensemble.
- Added institutional asset map, opportunity radar, four-bucket portfolio, paid-experiment register and 180-day transition plan.
- Added economic resilience, burden firewall, AI transparency manifest and nine governed Agent role mandates.
- Added read-only MCP reference subset, A2A 1.0 Agent Card, OpenAPI and loopback-only HTTP service.
- Added deterministic compilation, SHA-256 manifest verification, JSON Schemas, offline dashboard and 84 automated tests.
