@echo off
python run.py doctor || exit /b 1
python run.py demo --out outputs\demo || exit /b 1
python run.py verify --out outputs\demo || exit /b 1
echo Open outputs\demo\dashboard.html
