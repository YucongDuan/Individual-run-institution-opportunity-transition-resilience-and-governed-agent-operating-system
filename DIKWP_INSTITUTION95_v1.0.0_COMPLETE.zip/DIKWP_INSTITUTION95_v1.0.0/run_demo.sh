#!/usr/bin/env sh
set -eu
python run.py doctor
python run.py demo --out outputs/demo
python run.py verify --out outputs/demo
printf '%s\n' "Open outputs/demo/dashboard.html"
