# DIKWP-INSTITUTION95 v1.0.0 发布索引

## 发布包

- `DIKWP_INSTITUTION95_v1.0.0_COMPLETE.zip`：源码、文档、测试、示例输入、预编译演示、离线仪表盘与wheel。
- `DIKWP_INSTITUTION95_v1.0.0_SOURCE.zip`：源码、文档、测试与示例输入，不含预编译输出和wheel。
- `dikwp_institution95-1.0.0-py3-none-any.whl`：Python安装包。

## 直接审阅

- `DIKWP_INSTITUTION95_FULL_SYSTEM_REPORT_CN.html`
- `DIKWP_INSTITUTION95_FULL_SYSTEM_REPORT_CN.md`
- `DIKWP_INSTITUTION95_demo_dashboard.html`

## 机器可读核心

- `DIKWP_INSTITUTION95_institution_bundle.json`
- `DIKWP_INSTITUTION95_opportunity_radar.json`
- `DIKWP_INSTITUTION95_portfolio.json`
- `DIKWP_INSTITUTION95_transition_plan_180_days.json`
- `DIKWP_INSTITUTION95_agent_mandates.json`
- `DIKWP_INSTITUTION95_ai_transparency_manifest.json`
- `DIKWP_INSTITUTION95_economic_resilience.json`

## 核验

- `DIKWP_INSTITUTION95_RELEASE_VALIDATION.json`
- `DIKWP_INSTITUTION95_v1.0.0_SHA256SUMS.txt`

所有示例财务和资源数值均为可替换规划假设；机会分数不是收入预测；场景权重不是发生概率；外部行动、付款、身份和自动自我修改权限全部为0。
