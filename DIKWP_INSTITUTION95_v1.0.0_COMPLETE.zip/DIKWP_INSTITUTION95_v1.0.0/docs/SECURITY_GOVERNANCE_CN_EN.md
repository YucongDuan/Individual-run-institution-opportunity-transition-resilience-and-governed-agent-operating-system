# Security, Governance and Rights Boundaries / 安全、治理与权利边界

## 中文

1. 核心参考实现无外部自动行动、付款、身份或自我修改权限。  
2. HTTP服务只允许绑定`127.0.0.1`、`localhost`或`::1`，且所有POST请求返回405。  
3. MCP配置仅有只读工具；A2A Agent Card是本地参考，不含生产认证。  
4. 沉默、礼貌、出席会议、接收材料或曾接受免费帮助不构成购买、背书或授权。  
5. 公开内容不自动授予商业衍生、身份模拟、声音、官方代表或私有记忆使用权。  
6. 高影响输出须具名复核，保留来源、范围、停止与回滚条件。  
7. 权利争议触发商业衍生冻结；高杠杆一方承担更高的解释和负担分担义务。  
8. AI透明清单不是法律意见或合规证书。

## English

1. The reference core has zero automatic authority for external action, payment, identity, or self-modification.  
2. The HTTP server is loopback-only and rejects all POST operations.  
3. The MCP profile is read-only; the A2A Agent Card is a local reference, not a conformance certificate.  
4. Silence, politeness, meeting attendance, receipt of materials, or prior free assistance do not constitute purchase, endorsement, or authorization.  
5. Public availability does not grant commercial derivative, identity, voice, official representation, or private-memory rights.  
6. High-impact outputs require named review, provenance, scope, stop conditions, and rollback.  
7. Rights disputes freeze derivative commercialization; higher-leverage actors bear enhanced explanation and burden-sharing duties.  
8. The AI transparency manifest is not legal advice or a compliance certificate.
