# DIKWP-INSTITUTION95 技术架构

```text
外部事实与假说             个人／机构资产与权利
        │                          │
        ▼                          ▼
  Future Signal Ledger      Institutional Asset Map
        │                          │
        └──────────┬───────────────┘
                   ▼
        Plural Scenario Ensemble
                   ▼
          Opportunity Radar
                   ▼
    Cash / Compound / Option / Public
             Portfolio Engine
                   ▼
         Paid Experiment Register
                   ▼
     180-Day Transition Orchestrator
                   ▼
  Agent Mandates + Burden Firewall + AI Transparency
                   ▼
 MCP read-only / A2A Card / Loopback OpenAPI
                   ▼
     Decisions → Outcomes → Calibration → Revision
```

## 设计属性

- 本地优先；
- Python 3.10+标准库核心；
- 确定性编译；
- JSON与JSON Schema；
- 输出文件SHA-256清单；
- 只读互操作接口；
- 外部、付款、身份和自我修改权限为0；
- 可替换的规划假设；
- 不把机会分数伪装为预测。

## 命令行

```bash
institution95 doctor
institution95 demo --out outputs/demo
institution95 verify --out outputs/demo
institution95 radar --bundle outputs/demo/institution_bundle.json --limit 10
institution95 portfolio --bundle outputs/demo/institution_bundle.json
institution95 transition --bundle outputs/demo/institution_bundle.json
institution95 mandates --bundle outputs/demo/institution_bundle.json
institution95 serve --out outputs/demo --host 127.0.0.1 --port 8796
institution95 mcp --out outputs/demo
```
