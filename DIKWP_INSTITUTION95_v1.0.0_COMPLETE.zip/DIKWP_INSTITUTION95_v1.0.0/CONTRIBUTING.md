# Contributing

1. Keep the standard-library core free of mandatory network or cloud dependencies.
2. Preserve deterministic output for fixed inputs.
3. Add tests for every material change.
4. Do not add automatic external-action, payment, identity or self-modification authority.
5. Separate factual evidence, source-grounded inference and working hypotheses.
6. Preserve attribution, rights and claim boundaries.
7. Do not present planning scores as forecasts or guarantees.

Run:

```bash
PYTHONPATH=src python -m unittest discover -s tests -v
python run.py demo --out outputs/demo
python run.py verify --out outputs/demo
```
