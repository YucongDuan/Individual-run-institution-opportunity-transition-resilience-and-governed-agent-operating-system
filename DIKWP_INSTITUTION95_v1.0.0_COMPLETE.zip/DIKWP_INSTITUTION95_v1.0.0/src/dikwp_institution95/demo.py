from __future__ import annotations

from importlib.resources import files
from pathlib import Path
from typing import Any

from .compiler import compile_institution, write_manifest
from .utils import write_json
from .verify import verify_output


DEMO_SOURCE_DATE_EPOCH = "1788220800"  # 2026-09-01T00:00:00Z


def demo_data_dir() -> Path:
    return Path(str(files("dikwp_institution95").joinpath("data/demo")))


def create_demo(out_dir: str | Path) -> dict[str, Any]:
    data = demo_data_dir()
    result = compile_institution(
        owner_path=data / "owner.json",
        assets_path=data / "assets.json",
        signals_path=data / "signals.json",
        constraints_path=data / "constraints.json",
        opportunities_path=data / "opportunities.json",
        lineage_path=data / "lineage.json",
        out_dir=out_dir,
        source_date_epoch=DEMO_SOURCE_DATE_EPOCH,
    )
    verification = verify_output(out_dir)
    write_json(Path(out_dir) / "DEMO_VALIDATION.json", verification)
    write_manifest(out_dir, result["bundle"]["compile_id"])
    verification = verify_output(out_dir)
    if not verification["valid"]:
        raise RuntimeError(f"Demo verification failed: {verification['errors']}")
    return {**result, "verification": verification}
