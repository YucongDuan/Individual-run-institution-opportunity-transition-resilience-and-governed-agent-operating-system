from __future__ import annotations

from pathlib import Path
from typing import Any

from . import SYSTEM_NAME, __version__
from .utils import read_json, sha256_bytes, sha256_obj


def _deterministic_core(bundle: dict[str, Any]) -> dict[str, Any]:
    return {key: value for key, value in bundle.items() if key not in {"compile_id", "content_digest", "generated_at"}}


def verify_output(out_dir: str | Path) -> dict[str, Any]:
    out = Path(out_dir)
    errors: list[str] = []
    warnings: list[str] = []
    required = [
        "institution_bundle.json",
        "asset_map.json",
        "signal_map.json",
        "scenario_ensemble.json",
        "opportunity_radar.json",
        "portfolio.json",
        "institution_scorecard.json",
        "transition_plan_180_days.json",
        "paid_experiment_register.json",
        "economic_resilience.json",
        "agent_mandates.json",
        "ai_transparency_manifest.json",
        "burden_firewall.json",
        "source_registry.json",
        "lineage.json",
        "mcp_tool_manifest.json",
        "a2a_agent_card.json",
        "openapi.json",
        "dashboard.html",
        "VERIFY.txt",
        "MANIFEST.json",
    ]
    for name in required:
        if not (out / name).is_file():
            errors.append(f"MISSING:{name}")
    if errors:
        return {"valid": False, "errors": errors, "warnings": warnings, "checked_files": 0}

    bundle = read_json(out / "institution_bundle.json")
    if bundle.get("system") != SYSTEM_NAME:
        errors.append("SYSTEM_NAME_MISMATCH")
    if bundle.get("version") != __version__:
        errors.append("VERSION_MISMATCH")
    expected_digest = sha256_obj(_deterministic_core(bundle))
    if expected_digest != bundle.get("content_digest"):
        errors.append("CONTENT_DIGEST_MISMATCH")
    if not str(bundle.get("compile_id", "")).startswith("institution-"):
        errors.append("COMPILE_ID_FORMAT_INVALID")

    governance = bundle.get("governance", {})
    for key in (
        "automatic_external_action_authority",
        "automatic_payment_authority",
        "automatic_identity_authority",
        "automatic_self_modification_authority",
    ):
        if governance.get(key) != 0:
            errors.append(f"AUTHORITY_NOT_ZERO:{key}")

    scenario = bundle.get("scenario_ensemble", {})
    weight_sum = sum(float(row.get("stress_weight", 0)) for row in scenario.get("records", []))
    if abs(weight_sum - 1.0) > 1e-5:
        errors.append("SCENARIO_WEIGHTS_DO_NOT_SUM_TO_ONE")
    if "not calibrated" not in str(scenario.get("interpretation_boundary", "")).lower():
        errors.append("SCENARIO_FORECAST_BOUNDARY_MISSING")

    portfolio = bundle.get("portfolio", {})
    if abs(float(portfolio.get("portfolio_share_sum", 0)) - 1.0) > 1e-5:
        errors.append("PORTFOLIO_SHARE_SUM_INVALID")
    if not portfolio.get("boundary"):
        errors.append("PLANNING_ASSUMPTION_BOUNDARY_MISSING")

    opportunities = bundle.get("opportunity_radar", {}).get("records", [])
    for row in opportunities:
        if row.get("blocked") and row.get("recommendation") in {"GO_NOW", "PAID_TEST"}:
            errors.append(f"BLOCKED_OPPORTUNITY_RECOMMENDED:{row.get('opportunity_id')}")
        if row.get("recommendation") == "GO_NOW" and not any(g.get("gate") == "paid_boundary" and g.get("passed") for g in row.get("gates", [])):
            errors.append(f"UNPAID_GO_NOW:{row.get('opportunity_id')}")

    mandates = bundle.get("agent_mandates", {}).get("records", [])
    for mandate in mandates:
        if mandate.get("external_action_authority") != 0:
            errors.append(f"MANDATE_EXTERNAL_AUTHORITY:{mandate.get('role_id')}")
        if mandate.get("payment_authority") != 0:
            errors.append(f"MANDATE_PAYMENT_AUTHORITY:{mandate.get('role_id')}")
        if mandate.get("identity_authority") != 0:
            errors.append(f"MANDATE_IDENTITY_AUTHORITY:{mandate.get('role_id')}")
        if mandate.get("status") != "DRAFT_NOT_ACTIVATED":
            warnings.append(f"MANDATE_STATUS_NON_DEFAULT:{mandate.get('role_id')}")

    transparency = bundle.get("ai_transparency_manifest", {})
    if not transparency.get("direct_interaction_notice", {}).get("required"):
        errors.append("AI_INTERACTION_NOTICE_NOT_REQUIRED")
    if transparency.get("automatic_compliance_certificate") is not None:
        errors.append("FALSE_COMPLIANCE_CERTIFICATE")

    transition = bundle.get("transition_plan", {})
    if transition.get("automatic_transition_authority") != 0:
        errors.append("AUTOMATIC_TRANSITION_AUTHORITY_NOT_ZERO")
    if len(transition.get("phases", [])) != 5:
        errors.append("TRANSITION_PHASE_COUNT_INVALID")

    claim_boundaries = bundle.get("claim_boundaries", {})
    for key in (
        "future_scenario_weights_are_forecasts",
        "opportunity_scores_are_revenue_guarantees",
        "planning_assumptions_are_actual_owner_finances",
        "a2a_or_mcp_independent_conformance_certified",
        "ai_act_compliance_certified",
    ):
        if claim_boundaries.get(key) is not False:
            errors.append(f"CLAIM_BOUNDARY_INVALID:{key}")

    manifest = read_json(out / "MANIFEST.json")
    if manifest.get("compile_id") != bundle.get("compile_id"):
        errors.append("MANIFEST_COMPILE_ID_MISMATCH")
    checked = 0
    for item in manifest.get("files", []):
        path = out / item["path"]
        if not path.is_file():
            errors.append(f"MANIFEST_FILE_MISSING:{item['path']}")
            continue
        data = path.read_bytes()
        checked += 1
        if len(data) != int(item["bytes"]):
            errors.append(f"MANIFEST_SIZE_MISMATCH:{item['path']}")
        if sha256_bytes(data) != item["sha256"]:
            errors.append(f"MANIFEST_HASH_MISMATCH:{item['path']}")

    dashboard = (out / "dashboard.html").read_text(encoding="utf-8")
    if "<script src=" in dashboard.lower():
        errors.append("EXTERNAL_SCRIPT_REFERENCE_FOUND")
    if "automatic external action authority = 0" not in dashboard.lower():
        warnings.append("DASHBOARD_AUTHORITY_LABEL_NOT_FOUND")

    return {
        "valid": not errors,
        "system": bundle.get("system"),
        "version": bundle.get("version"),
        "compile_id": bundle.get("compile_id"),
        "content_digest": bundle.get("content_digest"),
        "checked_files": checked,
        "manifest_file_count": manifest.get("file_count"),
        "errors": errors,
        "warnings": warnings,
        "invariants": {
            "scenario_weight_sum": round(weight_sum, 6),
            "portfolio_share_sum": portfolio.get("portfolio_share_sum"),
            "agent_mandate_count": len(mandates),
            "external_action_authority": governance.get("automatic_external_action_authority"),
            "payment_authority": governance.get("automatic_payment_authority"),
            "identity_authority": governance.get("automatic_identity_authority"),
        },
    }
