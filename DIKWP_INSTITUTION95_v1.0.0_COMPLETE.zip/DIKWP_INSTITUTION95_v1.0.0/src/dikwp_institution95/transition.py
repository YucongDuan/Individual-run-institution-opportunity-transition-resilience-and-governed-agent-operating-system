from __future__ import annotations

from typing import Any

from .utils import clamp, safe_mean, stable_id


OPERATING_MODELS: list[dict[str, Any]] = [
    {
        "model_id": "author_expert",
        "name_cn": "作者／专家个体",
        "threshold": 0.00,
        "description": "价值主要依赖本人的时间、声誉与临场判断。",
        "key_risk": "收入与影响无法脱离本人可用小时。",
    },
    {
        "model_id": "productized_studio",
        "name_cn": "产品化工作室",
        "threshold": 0.30,
        "description": "将重复服务压缩为有边界、有价格、有验收标准的产品。",
        "key_risk": "产品仍由本人手工交付，复利不足。",
    },
    {
        "model_id": "agent_augmented_institution",
        "name_cn": "Agent增强型机构",
        "threshold": 0.48,
        "description": "多个受治理Agent承担研究、产品、交付、合规与记忆工作。",
        "key_risk": "权限和质量控制不足会放大声誉风险。",
    },
    {
        "model_id": "protocol_exposed_institution",
        "name_cn": "协议化能力机构",
        "threshold": 0.62,
        "description": "知识、工具和服务通过MCP、A2A或API被其他Agent安全发现和调用。",
        "key_risk": "缺少计量、身份和授权会使价值被上层平台捕获。",
    },
    {
        "model_id": "federated_micro_institution",
        "name_cn": "联邦化微型机构",
        "threshold": 0.76,
        "description": "与独立专家、实验室和交付伙伴按协议协作，不以固定雇员规模为核心。",
        "key_risk": "贡献、责任和客户关系可能被高杠杆伙伴攫取。",
    },
    {
        "model_id": "endowed_continuation_institution",
        "name_cn": "使命与继任型持续机构",
        "threshold": 0.88,
        "description": "拥有长期使命、储备、治理、继任与公共价值安排，可在创始人缺席时继续。",
        "key_risk": "后继机构可能僵化、神化创始人或偏离现实。",
    },
]


def _metric(value: Any, default: float = 0.0) -> float:
    return clamp(float(value if value is not None else default))


def build_institution_scorecard(
    owner: dict[str, Any],
    asset_map: dict[str, Any],
    opportunity_radar: dict[str, Any],
    constraints: dict[str, Any],
    lineage: dict[str, Any] | None = None,
) -> dict[str, Any]:
    metrics = constraints.get("current_metrics", {})
    assets = asset_map.get("records", [])
    opportunities = opportunity_radar.get("records", [])
    viable = [row for row in opportunities if not row.get("blocked") and row.get("recommendation") in {"GO_NOW", "PAID_TEST"}]
    rights = asset_map.get("summary", {}).get("mean_rights_readiness", 0.0)
    codification = safe_mean(
        0.45 * float(a.get("maturity", 0)) + 0.35 * float(a.get("transferability", 0.5)) + 0.20 * float(a.get("evidence_strength", 0))
        for a in assets
    )
    offer_clarity = safe_mean(
        0.45 * float(row.get("dimensions", {}).get("evidence_readiness", 0))
        + 0.30 * float(row.get("dimensions", {}).get("cash_speed", 0))
        + 0.25 * float(row.get("dimensions", {}).get("rights_readiness", 0))
        for row in viable[:5]
    )
    dimensions = {
        "asset_codification": round(clamp(codification), 4),
        "rights_clarity": round(_metric(rights), 4),
        "offer_repeatability": round(clamp(0.55 * offer_clarity + 0.45 * _metric(metrics.get("offer_repeatability", 0.35))), 4),
        "recurring_revenue": round(_metric(metrics.get("recurring_revenue_share", 0.10)), 4),
        "agent_governance": round(_metric(metrics.get("agent_governance", 0.65)), 4),
        "evidence_and_outcomes": round(_metric(metrics.get("evidence_and_outcomes", 0.55)), 4),
        "owned_distribution": round(_metric(metrics.get("owned_distribution", 0.45)), 4),
        "partner_federation": round(_metric(metrics.get("partner_federation", 0.30)), 4),
        "cash_resilience": round(clamp(float(constraints.get("planning_assumptions", {}).get("runway_months", 12)) / 24.0), 4),
        "owner_bottleneck_inverse": round(1.0 - _metric(metrics.get("owner_delivery_dependency", 0.80)), 4),
        "ai_transparency_readiness": round(_metric(metrics.get("ai_transparency_readiness", 0.60)), 4),
        "succession_and_continuity": round(_metric(metrics.get("succession_and_continuity", 0.35 if not lineage else 0.60)), 4),
    }
    weights = {
        "asset_codification": 0.10,
        "rights_clarity": 0.10,
        "offer_repeatability": 0.11,
        "recurring_revenue": 0.10,
        "agent_governance": 0.10,
        "evidence_and_outcomes": 0.10,
        "owned_distribution": 0.08,
        "partner_federation": 0.07,
        "cash_resilience": 0.08,
        "owner_bottleneck_inverse": 0.08,
        "ai_transparency_readiness": 0.05,
        "succession_and_continuity": 0.03,
    }
    composite = sum(dimensions[key] * weights[key] for key in dimensions)
    sorted_models = sorted(OPERATING_MODELS, key=lambda item: item["threshold"])
    current = sorted_models[0]
    for model in sorted_models:
        if composite >= model["threshold"]:
            current = model
    current_idx = next(i for i, model in enumerate(sorted_models) if model["model_id"] == current["model_id"])
    target = sorted_models[min(current_idx + 1, len(sorted_models) - 1)]
    weakest = sorted(dimensions.items(), key=lambda item: (item[1], item[0]))[:4]
    return {
        "scorecard_id": stable_id("institution-scorecard", dimensions, 24),
        "dimensions": dimensions,
        "weights": weights,
        "composite_navigation_score": round(composite, 4),
        "current_operating_model": current,
        "next_operating_model": target,
        "weakest_dimensions": [{"dimension": key, "score": value} for key, value in weakest],
        "viable_opportunity_count": len(viable),
        "interpretation_boundary": "This is an operating-system navigation score, not a rating of the person's worth, intelligence or social status.",
    }


def build_transition_plan(
    scorecard: dict[str, Any],
    opportunity_radar: dict[str, Any],
    portfolio: dict[str, Any],
    constraints: dict[str, Any],
) -> dict[str, Any]:
    selected = portfolio.get("selected", [])
    cash = next((row for row in selected if row["bucket"] == "cash_engine"), None)
    compound = next((row for row in selected if row["bucket"] == "compounding_asset"), None)
    option = next((row for row in selected if row["bucket"] == "strategic_option"), None)
    public = next((row for row in selected if row["bucket"] == "public_value"), None)
    names = {
        "cash": cash["name_cn"] if cash else "首个有预算负责人的付费试点",
        "compound": compound["name_cn"] if compound else "可复用认知资产产品",
        "option": option["name_cn"] if option else "协议化能力接口",
        "public": public["name_cn"] if public else "有资助来源的公共价值项目",
    }
    phases = [
        {
            "phase_id": "P0",
            "days": "1-14",
            "name_cn": "停止价值泄漏并建立机构底账",
            "objective": "停止无边界免费定制，明确资产、权利、价格、时间、现金和平台依赖。",
            "deliverables": ["机构章程", "停止清单", "资产与权利表", "现金与时间预算", "AI使用与披露规则"],
            "gates": ["所有定制工作均有书面范围", "公开资料与商业授权被分离", "外部自动行动权限保持为0"],
        },
        {
            "phase_id": "P1",
            "days": "15-45",
            "name_cn": "把专家劳动压缩为可购买产品",
            "objective": f"围绕“{names['cash']}”形成一个现金引擎，并为“{names['compound']}”建立复利资产。",
            "deliverables": ["三个以内产品页", "价格底线", "交付模板", "验收标准", "案例与证据包"],
            "gates": ["不超过三个首发产品", "每个产品有明确买方与预算来源", "至少一个产品可在本人缺席时部分交付"],
        },
        {
            "phase_id": "P2",
            "days": "46-90",
            "name_cn": "完成三个付费设计伙伴验证",
            "objective": "以现实付款、复购意愿和交付成本，而非点赞与访问量验证需求。",
            "deliverables": ["三份付费试点合同或采购依据", "结果记录", "客户异议库", "单位经济性", "可复用资产增量"],
            "gates": ["不以免费原型冒充商业验证", "每次试点都产生可复用资产", "未满足复购门槛的产品被缩减或退役"],
        },
        {
            "phase_id": "P3",
            "days": "91-135",
            "name_cn": "建立受治理Agent岗位与服务流水线",
            "objective": "让Agent承担检索、证据、产品、交付、合规和复盘，但不夺取身份、付款或发布权。",
            "deliverables": ["Agent岗位说明", "能力令牌", "人工复核门", "质量基准", "异常与回滚记录"],
            "gates": ["重复交付工时下降30%", "来源和AI披露覆盖率达到90%", "高影响输出必须具名批准"],
        },
        {
            "phase_id": "P4",
            "days": "136-180",
            "name_cn": "协议化、联邦化与继任预备",
            "objective": f"将“{names['option']}”暴露为可计量接口，并以“{names['public']}”建立信任而不形成无偿负担。",
            "deliverables": ["只读MCP/A2A参考接口", "伙伴贡献合同", "客户与平台集中度看板", "继任与停机预案", "公共项目资助规则"],
            "gates": ["单一客户收入低于30%", "单一平台依赖低于35%", "公共项目有独立预算", "继任不等于身份冒充"],
        },
    ]
    triggers = [
        {
            "trigger": "runway_months_below_6",
            "response": "现金引擎提高到65%；冻结无资助的长期项目；不得以免费定制换取模糊机会。",
            "reversible": True,
        },
        {
            "trigger": "one_client_revenue_above_30_percent",
            "response": "停止扩大该客户定制范围，优先产品化与新增渠道。",
            "reversible": True,
        },
        {
            "trigger": "owner_delivery_dependency_above_60_percent",
            "response": "拆分任务、建立标准、Agent岗位和伙伴交付；暂停新增手工服务。",
            "reversible": True,
        },
        {
            "trigger": "rights_or_attribution_dispute",
            "response": "冻结商业发布与衍生使用，保留记录并转入具名书面澄清。",
            "reversible": True,
        },
        {
            "trigger": "platform_dependency_above_35_percent",
            "response": "建立自有名单、开放协议和离线导出；不得把机构身份绑定到单一平台。",
            "reversible": True,
        },
        {
            "trigger": "AI_public_content_without_review_or_label",
            "response": "阻止发布，要求AI披露、来源和具名复核。",
            "reversible": True,
        },
    ]
    return {
        "transition_plan_id": stable_id("transition-plan", {"scorecard": scorecard["scorecard_id"], "selected": [s["opportunity_id"] for s in selected]}, 24),
        "from_model": scorecard["current_operating_model"],
        "target_model": scorecard["next_operating_model"],
        "phases": phases,
        "transition_triggers": triggers,
        "decision_authority": "named_owner_or_written_delegate",
        "automatic_transition_authority": 0,
        "retirement_rule": "A transition is reversed when its real outcomes increase unpaid burden, concentration, rights risk or owner fragility without compensating value.",
    }


def operating_model_registry() -> list[dict[str, Any]]:
    return [dict(item) for item in OPERATING_MODELS]
