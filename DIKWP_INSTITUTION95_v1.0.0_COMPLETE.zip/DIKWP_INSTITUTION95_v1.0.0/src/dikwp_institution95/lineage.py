from __future__ import annotations

from pathlib import Path
from typing import Any

from .utils import read_json, sha256_obj, stable_id


def _summarize_praxis(bundle: dict[str, Any]) -> dict[str, Any]:
    return {
        "system": bundle.get("system"),
        "version": bundle.get("version"),
        "compile_id": bundle.get("compile_id"),
        "content_digest": bundle.get("content_digest"),
        "knowledge_unit_count": len(bundle.get("knowledge_units", [])),
        "product_count": len(bundle.get("product_catalog", {}).get("products", [])),
        "automatic_external_action_authority": bundle.get("governance", {}).get("automatic_external_action_authority"),
        "role": "cognitive_capital_and_governed_expert_service_upstream",
    }


def _summarize_successor(bundle: dict[str, Any]) -> dict[str, Any]:
    return {
        "system": bundle.get("system"),
        "version": bundle.get("version"),
        "compile_id": bundle.get("compilation_id"),
        "content_digest": bundle.get("bundle_digest"),
        "public_contribution_candidates": len(bundle.get("contribution_portfolio", {}).get("candidates", [])),
        "current_runtime_mode": bundle.get("succession_state", {}).get("current_runtime_mode"),
        "automatic_external_action_authority": bundle.get("automatic_external_action_authority"),
        "role": "premortem_coevolution_and_continuity_upstream",
    }


def build_lineage(
    declared_lineage: dict[str, Any] | None = None,
    praxis_bundle_path: str | Path | None = None,
    successor_bundle_path: str | Path | None = None,
) -> dict[str, Any]:
    records: list[dict[str, Any]] = []
    for record in (declared_lineage or {}).get("records", []):
        records.append(dict(record))
    if praxis_bundle_path:
        records.append(_summarize_praxis(read_json(praxis_bundle_path)))
    if successor_bundle_path:
        records.append(_summarize_successor(read_json(successor_bundle_path)))
    unique: dict[tuple[str, str], dict[str, Any]] = {}
    for record in records:
        key = (str(record.get("system")), str(record.get("compile_id")))
        unique[key] = record
    normalized = sorted(unique.values(), key=lambda item: (str(item.get("system")), str(item.get("compile_id"))))
    return {
        "lineage_id": stable_id("institution-lineage", normalized, 24),
        "records": normalized,
        "lineage_digest": sha256_obj(normalized),
        "import_rule": "Imported upstream systems contribute declared capabilities and provenance; they do not silently transfer identity, authorization, legal status or empirical claims.",
        "automatic_semantic_overwrite": False,
    }
