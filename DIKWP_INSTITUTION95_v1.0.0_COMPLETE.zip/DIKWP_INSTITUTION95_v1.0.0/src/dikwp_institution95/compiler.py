from __future__ import annotations

from pathlib import Path
from typing import Any

from . import DEFAULT_MODE, SYSTEM_NAME, __version__
from .assets import build_asset_map
from .economics import build_economic_resilience
from .experiments import build_paid_experiments
from .governance import build_agent_mandates, build_ai_transparency_manifest, build_burden_firewall
from .interop import build_a2a_agent_card, build_mcp_manifest, build_openapi
from .lineage import build_lineage
from .opportunities import build_opportunity_radar
from .portfolio import build_portfolio
from .render import render_dashboard
from .scenarios import build_scenario_ensemble
from .signals import build_signal_map
from .transition import build_institution_scorecard, build_transition_plan, operating_model_registry
from .utils import load_list, public_file_hashes, read_json, sha256_obj, stable_id, timestamp_iso, write_json



def _source_registry(signals: list[dict[str, Any]], owner: dict[str, Any]) -> dict[str, Any]:
    records: dict[str, dict[str, Any]] = {}
    for signal in signals:
        source = signal.get("source") or {}
        source_id = str(source.get("source_id") or stable_id("source", source, 18))
        records[source_id] = {
            "source_id": source_id,
            "title": source.get("title"),
            "publisher": source.get("publisher"),
            "url": source.get("url"),
            "published_date": source.get("published_date"),
            "retrieved_date": source.get("retrieved_date", "2026-09-01"),
            "source_type": source.get("source_type", "external_reference"),
            "scope_note": source.get("scope_note"),
        }
    for source in owner.get("source_registry", []):
        sid = str(source.get("source_id") or stable_id("source", source, 18))
        records[sid] = {**source, "source_id": sid}
    return {
        "records": sorted(records.values(), key=lambda item: item["source_id"]),
        "count": len(records),
        "boundary": "A source record supports only the scoped claim for which it was registered; citation does not imply endorsement of the whole system.",
    }


def _institution_constitution(owner: dict[str, Any], constraints: dict[str, Any]) -> dict[str, Any]:
    return {
        "institution_id": stable_id("institution", {"owner_id": owner["owner_id"], "mission": owner.get("mission")}, 22),
        "owner_id": owner["owner_id"],
        "display_name": owner.get("display_name"),
        "mission": owner.get("mission"),
        "public_value_commitment": owner.get("public_value_commitment"),
        "communication_default": owner.get("communication_default", "written_asynchronous_first"),
        "operating_principles": [
            "One person may remain the constitutional owner while governed Agents and independent partners perform bounded institutional roles.",
            "Knowledge visibility does not erase commercial, identity, attribution or representation rights.",
            "Real payment and outcome evidence outrank attention metrics as market validation.",
            "The institution preserves at least two non-isomorphic future models and prewrites evidence that would distinguish them.",
            "The higher-leverage counterparty carries a higher duty to clarify scope, attribution, burden and exit rights.",
            "Public-value work must have a capped owner subsidy or an independent funding source.",
            "Continuity serves the mission and affected people; self-preservation is not an overriding objective.",
        ],
        "constitutional_boundaries": constraints.get("non_negotiable_boundaries", []),
        "automatic_external_action_authority": 0,
        "automatic_payment_authority": 0,
        "automatic_identity_authority": 0,
    }


def write_manifest(out_dir: str | Path, compile_id: str) -> dict[str, Any]:
    out = Path(out_dir)
    files = public_file_hashes(out, exclude={"MANIFEST.json"})
    manifest = {
        "system": SYSTEM_NAME,
        "version": __version__,
        "compile_id": compile_id,
        "file_count": len(files),
        "files": files,
    }
    write_json(out / "MANIFEST.json", manifest)
    return manifest


def compile_institution(
    *,
    owner_path: str | Path,
    assets_path: str | Path,
    signals_path: str | Path,
    constraints_path: str | Path,
    opportunities_path: str | Path,
    lineage_path: str | Path | None,
    out_dir: str | Path,
    praxis_bundle_path: str | Path | None = None,
    successor_bundle_path: str | Path | None = None,
    source_date_epoch: str | None = None,
) -> dict[str, Any]:
    owner = read_json(owner_path)
    assets = load_list(assets_path, "assets")
    signals = load_list(signals_path, "signals")
    constraints = read_json(constraints_path)
    templates = load_list(opportunities_path, "opportunities")
    declared_lineage = read_json(lineage_path) if lineage_path else None
    if not owner.get("owner_id"):
        raise ValueError("owner_id is required")
    if constraints.get("automatic_external_action_authority", 0) != 0:
        raise ValueError("Reference release requires automatic_external_action_authority=0")

    asset_map = build_asset_map(assets)
    signal_map = build_signal_map(signals)
    scenario_ensemble = build_scenario_ensemble(signal_map)
    opportunity_radar = build_opportunity_radar(
        templates,
        asset_map=asset_map,
        signal_map=signal_map,
        scenario_ensemble=scenario_ensemble,
        constraints=constraints,
    )
    portfolio = build_portfolio(opportunity_radar, constraints, owner)
    lineage = build_lineage(declared_lineage, praxis_bundle_path, successor_bundle_path)
    scorecard = build_institution_scorecard(owner, asset_map, opportunity_radar, constraints, lineage)
    transition_plan = build_transition_plan(scorecard, opportunity_radar, portfolio, constraints)
    experiment_register = build_paid_experiments(opportunity_radar)
    economic_resilience = build_economic_resilience(constraints, opportunity_radar)
    agent_mandates = build_agent_mandates(owner, constraints)
    ai_transparency = build_ai_transparency_manifest(owner, constraints)
    burden_firewall = build_burden_firewall(owner, constraints)
    source_registry = _source_registry(signals, owner)
    interop = {
        "mcp": build_mcp_manifest(),
        "a2a_agent_card": build_a2a_agent_card(),
        "openapi": build_openapi(),
    }
    deterministic_core = {
        "system": SYSTEM_NAME,
        "version": __version__,
        "mesh_mode": DEFAULT_MODE,
        "owner": owner,
        "institution_constitution": _institution_constitution(owner, constraints),
        "asset_map": asset_map,
        "signal_map": signal_map,
        "scenario_ensemble": scenario_ensemble,
        "opportunity_radar": opportunity_radar,
        "portfolio": portfolio,
        "institution_scorecard": scorecard,
        "transition_plan": transition_plan,
        "experiment_register": experiment_register,
        "economic_resilience": economic_resilience,
        "agent_mandates": agent_mandates,
        "ai_transparency_manifest": ai_transparency,
        "burden_firewall": burden_firewall,
        "operating_model_registry": operating_model_registry(),
        "source_registry": source_registry,
        "lineage": lineage,
        "interop": interop,
        "governance": {
            "factual_stance": "FACTUALLY_OBJECTIVE_RELATIONALLY_PROTECTIVE",
            "consent_acknowledgement_endorsement_separated": True,
            "creator_rights_first": True,
            "higher_leverage_actor_duty": "enhanced",
            "human_approval_for_high_impact": True,
            "public_metrics_do_not_equal_private_authorization": True,
            "automatic_external_action_authority": 0,
            "automatic_payment_authority": 0,
            "automatic_identity_authority": 0,
            "automatic_self_modification_authority": 0,
            "commercial_or_legal_certificate": None,
        },
        "claim_boundaries": {
            "future_scenario_weights_are_forecasts": False,
            "opportunity_scores_are_revenue_guarantees": False,
            "planning_assumptions_are_actual_owner_finances": False,
            "a2a_or_mcp_independent_conformance_certified": False,
            "ai_act_compliance_certified": False,
            "automatic_external_actions_executed": 0,
        },
    }
    content_digest = sha256_obj(deterministic_core)
    compile_id = stable_id("institution", {"content_digest": content_digest}, 28)
    bundle = {
        **deterministic_core,
        "compile_id": compile_id,
        "content_digest": content_digest,
        "generated_at": timestamp_iso(source_date_epoch),
    }
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    write_json(out / "institution_bundle.json", bundle)
    write_json(out / "asset_map.json", asset_map)
    write_json(out / "signal_map.json", signal_map)
    write_json(out / "scenario_ensemble.json", scenario_ensemble)
    write_json(out / "opportunity_radar.json", opportunity_radar)
    write_json(out / "portfolio.json", portfolio)
    write_json(out / "institution_scorecard.json", scorecard)
    write_json(out / "transition_plan_180_days.json", transition_plan)
    write_json(out / "paid_experiment_register.json", experiment_register)
    write_json(out / "economic_resilience.json", economic_resilience)
    write_json(out / "agent_mandates.json", agent_mandates)
    write_json(out / "ai_transparency_manifest.json", ai_transparency)
    write_json(out / "burden_firewall.json", burden_firewall)
    write_json(out / "source_registry.json", source_registry)
    write_json(out / "lineage.json", lineage)
    write_json(out / "mcp_tool_manifest.json", interop["mcp"])
    write_json(out / "a2a_agent_card.json", interop["a2a_agent_card"])
    write_json(out / "openapi.json", interop["openapi"])
    (out / "decision_ledger.jsonl").write_text("", encoding="utf-8")
    (out / "outcome_ledger.jsonl").write_text("", encoding="utf-8")
    (out / "dashboard.html").write_text(render_dashboard(bundle), encoding="utf-8")
    (out / "VERIFY.txt").write_text(
        "\n".join([
            SYSTEM_NAME,
            f"version={__version__}",
            f"compile_id={compile_id}",
            f"content_digest={content_digest}",
            "automatic_external_action_authority=0",
            "automatic_payment_authority=0",
            "automatic_identity_authority=0",
            "scenario_weights_are_forecasts=false",
            "opportunity_scores_are_revenue_guarantees=false",
            "",
        ]),
        encoding="utf-8",
    )
    manifest = write_manifest(out, compile_id)
    return {"bundle": bundle, "manifest": manifest, "out_dir": str(out)}
