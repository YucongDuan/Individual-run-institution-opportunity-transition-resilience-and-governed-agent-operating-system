from __future__ import annotations

from html import escape
from typing import Any


def _pct(value: float) -> str:
    return f"{float(value) * 100:.1f}%"


def _bar(value: float, label: str, subtitle: str = "") -> str:
    width = max(0.0, min(100.0, float(value) * 100))
    return (
        '<div class="bar-row">'
        f'<div class="bar-head"><span>{escape(label)}</span><b>{width:.1f}%</b></div>'
        f'<div class="bar-track"><div class="bar-fill" style="width:{width:.2f}%"></div></div>'
        f'<div class="muted small">{escape(subtitle)}</div>'
        '</div>'
    )


def render_dashboard(bundle: dict[str, Any]) -> str:
    scorecard = bundle["institution_scorecard"]
    scenarios = bundle["scenario_ensemble"]["records"]
    opportunities = bundle["opportunity_radar"]["records"]
    portfolio = bundle["portfolio"]["selected"]
    phases = bundle["transition_plan"]["phases"]
    signals = bundle["signal_map"]["records"]
    owner = bundle["owner"]
    cards = [
        ("当前机构模式", scorecard["current_operating_model"]["name_cn"], scorecard["current_operating_model"]["model_id"]),
        ("下一目标模式", scorecard["next_operating_model"]["name_cn"], scorecard["next_operating_model"]["model_id"]),
        ("机构化导航分", _pct(scorecard["composite_navigation_score"]), "不是对个人价值的评分"),
        ("可行动机会", str(bundle["opportunity_radar"]["go_now_count"] + bundle["opportunity_radar"]["paid_test_count"]), "仅含通过权利与付费边界者"),
        ("规划跑道", f"{bundle['portfolio']['runway_months_assumption']:.1f}个月", "示例假设，部署前须替换"),
        ("外部自动行动", "0", "所有对外动作须具名授权"),
    ]
    card_html = "".join(
        f'<article class="stat"><div class="eyebrow">{escape(title)}</div><div class="big">{escape(value)}</div><div class="muted">{escape(note)}</div></article>'
        for title, value, note in cards
    )
    scenario_html = "".join(_bar(row["stress_weight"], row["name_cn"], row["thesis"]) for row in scenarios)
    signal_html = "".join(
        f'<tr><td>{escape(row["title"])}</td><td>{escape(row["category"])}</td><td>{escape(row["epistemic_status"])}</td><td>{_pct(row["strategic_significance"])}</td><td>{escape(row["horizon"])}</td></tr>'
        for row in signals[:10]
    )
    opp_html = "".join(
        f'<tr><td><b>{escape(row["name_cn"])}</b><div class="muted small">{escape(row.get("business_model", ""))}</div></td>'
        f'<td>{escape(row["portfolio_bucket"])}</td><td>{_pct(row["strategic_score"])}</td>'
        f'<td><span class="pill {"good" if row["recommendation"] == "GO_NOW" else "warn" if row["recommendation"] == "PAID_TEST" else "neutral"}">{escape(row["recommendation"])}</span></td>'
        f'<td>{escape(str(row.get("price_floor", 0)))}</td>'
        f'<td>{"是" if row["blocked"] else "否"}</td></tr>'
        for row in opportunities
    )
    portfolio_html = "".join(
        f'<article class="portfolio-card"><div class="eyebrow">{escape(row["bucket_label_cn"])}</div><h3>{escape(row["name_cn"])}</h3>'
        f'<div class="metric-line"><span>组合占比</span><b>{_pct(row["portfolio_share"])}</b></div>'
        f'<div class="metric-line"><span>本人每周时间</span><b>{row["owner_hours_per_week"]:.2f}h</b></div>'
        f'<div class="metric-line"><span>月试验预算</span><b>{row["monthly_experiment_budget"]:.0f}</b></div>'
        f'<div class="muted small">{escape(row["business_model"])}</div></article>'
        for row in portfolio
    )
    timeline_html = "".join(
        f'<article class="phase"><div class="phase-no">{escape(row["phase_id"])}</div><div><div class="eyebrow">第{escape(row["days"])}天</div><h3>{escape(row["name_cn"])}</h3><p>{escape(row["objective"])}</p>'
        f'<div class="tagline">{"".join(f"<span class=\"tag\">{escape(item)}</span>" for item in row["deliverables"][:4])}</div></div></article>'
        for row in phases
    )
    score_html = "".join(_bar(value, key.replace("_", " ")) for key, value in scorecard["dimensions"].items())
    selected_opps = [row for row in opportunities if row["opportunity_id"] in bundle["opportunity_radar"]["recommended_ids"]][:4]
    thesis_html = "".join(
        f'<li><b>{escape(row["name_cn"])}</b>：{escape(row.get("value_proposition", row.get("pilot_hypothesis", "")))}</li>'
        for row in selected_opps
    )
    return f"""<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title>DIKWP-INSTITUTION95 · 个体机构化机会与转型看板</title>
<style>
:root{{--ink:#0d1b2a;--muted:#5f6f81;--paper:#f5f7fb;--card:#ffffff;--line:#dce3ec;--accent:#1f6feb;--accent2:#0f9d7a;--warn:#c98200;--danger:#b42318;--shadow:0 10px 30px rgba(16,42,67,.08)}}
*{{box-sizing:border-box}} body{{margin:0;background:linear-gradient(135deg,#eef4ff 0%,#f7f8fb 45%,#effaf6 100%);font-family:Inter,"Noto Sans SC","Microsoft YaHei",system-ui,sans-serif;color:var(--ink);line-height:1.6}}
.shell{{max-width:1360px;margin:auto;padding:34px}} header{{padding:28px 30px;background:linear-gradient(120deg,#0d1b2a,#153b64 60%,#0a6c5b);color:white;border-radius:22px;box-shadow:var(--shadow)}}
h1{{font-size:clamp(30px,4vw,58px);line-height:1.08;margin:8px 0}} h2{{font-size:25px;margin:0 0 18px}} h3{{margin:5px 0 9px}} p{{margin:8px 0}} .subtitle{{max-width:950px;font-size:18px;color:#dce9f7}}
.eyebrow{{font-size:12px;text-transform:uppercase;letter-spacing:.11em;font-weight:800;opacity:.78}} .muted{{color:var(--muted)}} .small{{font-size:12px}}
.grid{{display:grid;gap:18px}} .stats{{grid-template-columns:repeat(auto-fit,minmax(190px,1fr));margin-top:20px}} .stat,.panel,.portfolio-card{{background:var(--card);border:1px solid rgba(220,227,236,.9);border-radius:18px;box-shadow:var(--shadow)}} .stat{{padding:18px}} .big{{font-size:25px;font-weight:850;margin:4px 0}}
.two{{grid-template-columns:repeat(auto-fit,minmax(420px,1fr));margin-top:22px}} .panel{{padding:23px}} .bar-row{{margin:14px 0}} .bar-head{{display:flex;justify-content:space-between;gap:18px}} .bar-track{{height:9px;background:#e8edf3;border-radius:999px;overflow:hidden;margin:6px 0}} .bar-fill{{height:100%;background:linear-gradient(90deg,var(--accent),var(--accent2));border-radius:999px}}
table{{width:100%;border-collapse:collapse;font-size:13px}} th,td{{padding:12px 10px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top}} th{{font-size:11px;letter-spacing:.06em;text-transform:uppercase;color:var(--muted)}} .table-wrap{{overflow:auto}}
.pill{{display:inline-block;border-radius:999px;padding:3px 9px;font-size:11px;font-weight:800}} .pill.good{{background:#dcf7ed;color:#067a5b}} .pill.warn{{background:#fff1ce;color:#8c5b00}} .pill.neutral{{background:#eef2f7;color:#506175}}
.portfolios{{grid-template-columns:repeat(auto-fit,minmax(230px,1fr))}} .portfolio-card{{padding:18px}} .metric-line{{display:flex;justify-content:space-between;border-top:1px dashed var(--line);padding:8px 0}}
.timeline{{display:grid;gap:13px}} .phase{{display:grid;grid-template-columns:64px 1fr;gap:16px;padding:18px;border:1px solid var(--line);border-radius:16px;background:#fff}} .phase-no{{width:54px;height:54px;border-radius:15px;background:#122b49;color:#fff;display:flex;align-items:center;justify-content:center;font-weight:900}}
.tagline{{display:flex;gap:7px;flex-wrap:wrap;margin-top:8px}} .tag{{font-size:11px;padding:4px 8px;border-radius:7px;background:#edf4ff;color:#214b7b}} .callout{{border-left:5px solid var(--accent2);background:#ecfbf6;padding:14px 16px;border-radius:10px}}
footer{{text-align:center;color:var(--muted);font-size:12px;padding:30px 0}} @media(max-width:650px){{.shell{{padding:15px}}.two{{grid-template-columns:1fr}}header{{padding:20px}}}}
</style>
</head>
<body><main class="shell">
<header>
<div class="eyebrow">MESH95 · Institution of One Operating System</div>
<h1>个体，不再只是自由职业者；<br/>而是一家可持续、可审计、可继任的机构。</h1>
<p class="subtitle">面向AI劳动重估、Agent协议经济、平台封闭、可信合规溢价与社会冲击，把个人知识、声誉、系统、关系和使命转化为可运营的机构资产。</p>
<p class="small">Owner: {escape(owner.get('display_name',''))} · Compile ID: {escape(bundle['compile_id'])} · Generated: {escape(bundle['generated_at'])}</p>
</header>
<section class="grid stats">{card_html}</section>
<section class="grid two">
<div class="panel"><div class="eyebrow">Plural Futures</div><h2>未来世界压力组合</h2><div class="callout">这些权重用于压力测试，不是预测概率。系统必须保留非同构未来，并允许现实结果使模型降权或退役。</div>{scenario_html}</div>
<div class="panel"><div class="eyebrow">Institution Readiness</div><h2>机构化能力向量</h2>{score_html}</div>
</section>
<section class="panel" style="margin-top:22px"><div class="eyebrow">Opportunity Radar</div><h2>机会雷达</h2><div class="table-wrap"><table><thead><tr><th>机会</th><th>组合桶</th><th>分数</th><th>建议</th><th>价格底线</th><th>阻断</th></tr></thead><tbody>{opp_html}</tbody></table></div></section>
<section class="panel" style="margin-top:22px"><div class="eyebrow">Portfolio</div><h2>时间与试验预算组合</h2><div class="grid portfolios">{portfolio_html}</div></section>
<section class="grid two">
<div class="panel"><div class="eyebrow">Signals</div><h2>高优先级变化信号</h2><div class="table-wrap"><table><thead><tr><th>信号</th><th>类别</th><th>证据地位</th><th>显著度</th><th>窗口</th></tr></thead><tbody>{signal_html}</tbody></table></div></div>
<div class="panel"><div class="eyebrow">Strategic Thesis</div><h2>首批商业化抓手</h2><ol>{thesis_html}</ol><div class="callout"><b>硬边界：</b>没有预算负责人、书面范围、权利清理和停止条件，不进入定制交付。</div></div>
</section>
<section class="panel" style="margin-top:22px"><div class="eyebrow">180-Day Transition</div><h2>180天机构化转型</h2><div class="timeline">{timeline_html}</div></section>
<footer>DIKWP-INSTITUTION95 · Automatic external action authority = 0 · Planning aid, not financial, legal or investment advice.</footer>
</main></body></html>"""
