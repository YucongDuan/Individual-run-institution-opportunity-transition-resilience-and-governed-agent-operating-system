from __future__ import annotations

from typing import Any

from .utils import clamp, money_round, stable_id


def build_economic_resilience(
    constraints: dict[str, Any],
    opportunity_radar: dict[str, Any],
) -> dict[str, Any]:
    assumptions = constraints.get("planning_assumptions", {})
    currency = assumptions.get("currency", "CNY")
    reserve = max(0.0, float(assumptions.get("cash_reserve", 0)))
    fixed = max(0.0, float(assumptions.get("monthly_fixed_cost", 0)))
    experiment = max(0.0, float(assumptions.get("monthly_experiment_budget", 0)))
    monthly_burn = fixed + experiment
    computed_runway = reserve / monthly_burn if monthly_burn > 0 else float(assumptions.get("runway_months", 0))
    declared_runway = float(assumptions.get("runway_months", computed_runway))
    runway = min(declared_runway, computed_runway) if reserve > 0 and monthly_burn > 0 else declared_runway
    viable = [
        row for row in opportunity_radar.get("records", [])
        if not row.get("blocked") and row.get("recommendation") in {"GO_NOW", "PAID_TEST"}
    ]
    cash_products = sorted(
        [row for row in viable if row.get("portfolio_bucket") == "cash_engine" and float(row.get("price_floor", 0)) > 0],
        key=lambda row: (-row["strategic_score"], row["opportunity_id"]),
    )
    break_even: list[dict[str, Any]] = []
    for row in cash_products[:4]:
        price = float(row.get("price_floor", 0))
        gross_margin = clamp(row.get("target_gross_margin", 0.70), 0.05, 0.95)
        contribution = price * gross_margin
        pilots = int((monthly_burn + contribution - 1) // contribution) if contribution > 0 else None
        break_even.append({
            "opportunity_id": row["opportunity_id"],
            "name_cn": row["name_cn"],
            "price_floor": money_round(price),
            "target_gross_margin": round(gross_margin, 4),
            "contribution_per_sale": money_round(contribution),
            "sales_per_month_to_cover_assumed_burn": pilots,
        })
    if runway < 6:
        resilience_state = "CRITICAL"
    elif runway < 12:
        resilience_state = "TIGHT"
    elif runway < 24:
        resilience_state = "OPERABLE"
    else:
        resilience_state = "OPTION_RICH"
    revenue_architecture = [
        {"layer": "L1", "name_cn": "高信任付费诊断／试点", "purpose": "快速现金与真实需求验证", "target_share": 0.35},
        {"layer": "L2", "name_cn": "产品化交付与订阅", "purpose": "降低本人时薪依赖", "target_share": 0.30},
        {"layer": "L3", "name_cn": "许可、API与Agent调用", "purpose": "形成可扩展认知资产收入", "target_share": 0.20},
        {"layer": "L4", "name_cn": "赞助、标准与公共项目", "purpose": "让公共价值拥有独立预算", "target_share": 0.10},
        {"layer": "L5", "name_cn": "培训与认证合作", "purpose": "扩展伙伴网络而非无限手工交付", "target_share": 0.05},
    ]
    return {
        "economic_resilience_id": stable_id("economic-resilience", {"runway": runway, "break_even": break_even}, 24),
        "planning_assumptions": {
            "currency": currency,
            "cash_reserve": money_round(reserve),
            "monthly_fixed_cost": money_round(fixed),
            "monthly_experiment_budget": money_round(experiment),
            "monthly_assumed_burn": money_round(monthly_burn),
            "declared_runway_months": round(declared_runway, 2),
            "computed_runway_months": round(computed_runway, 2),
            "conservative_runway_months": round(runway, 2),
        },
        "resilience_state": resilience_state,
        "break_even_examples": break_even,
        "revenue_architecture": revenue_architecture,
        "concentration_guardrails": constraints.get("portfolio_guardrails", {}),
        "cash_rules": [
            "A verbal opportunity is not pipeline value until a budget owner and next written action exist.",
            "Unpaid custom work is recorded as owner-financed investment, not as revenue or market validation.",
            "Public-good work receives a capped allocation or an external funding source.",
            "Long receivables and one-client concentration reduce effective runway even when booked revenue appears high.",
        ],
        "boundary": "All monetary values are replaceable planning assumptions, not statements about the owner's actual finances or financial advice.",
    }
