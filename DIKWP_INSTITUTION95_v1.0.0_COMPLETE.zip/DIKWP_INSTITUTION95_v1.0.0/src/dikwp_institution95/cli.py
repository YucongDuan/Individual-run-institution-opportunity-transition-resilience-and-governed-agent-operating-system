from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
from typing import Any

from . import (
    AUTOMATIC_EXTERNAL_ACTION_AUTHORITY,
    AUTOMATIC_IDENTITY_AUTHORITY,
    AUTOMATIC_PAYMENT_AUTHORITY,
    DEFAULT_MODE,
    DISPLAY_NAME,
    SYSTEM_NAME,
    __version__,
)
from .compiler import compile_institution
from .demo import create_demo
from .mcp_stdio import run_stdio
from .server import serve
from .utils import read_json
from .verify import verify_output


def _print(value: Any) -> None:
    print(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False))


def cmd_doctor(_: argparse.Namespace) -> int:
    _print({
        "system": SYSTEM_NAME,
        "display_name": DISPLAY_NAME,
        "version": __version__,
        "python": sys.version.split()[0],
        "mesh_mode": DEFAULT_MODE,
        "stdlib_only_core": True,
        "interfaces": ["CLI", "loopback read-only HTTP", "MCP 2026-07-28 reference subset", "A2A 1.0 Agent Card"],
        "automatic_external_action_authority": AUTOMATIC_EXTERNAL_ACTION_AUTHORITY,
        "automatic_payment_authority": AUTOMATIC_PAYMENT_AUTHORITY,
        "automatic_identity_authority": AUTOMATIC_IDENTITY_AUTHORITY,
    })
    return 0


def cmd_compile(args: argparse.Namespace) -> int:
    result = compile_institution(
        owner_path=args.owner,
        assets_path=args.assets,
        signals_path=args.signals,
        constraints_path=args.constraints,
        opportunities_path=args.opportunities,
        lineage_path=args.lineage,
        out_dir=args.out,
        praxis_bundle_path=args.praxis_bundle,
        successor_bundle_path=args.successor_bundle,
        source_date_epoch=args.source_date_epoch,
    )
    _print({
        "compile_id": result["bundle"]["compile_id"],
        "content_digest": result["bundle"]["content_digest"],
        "out_dir": result["out_dir"],
        "manifest_file_count": result["manifest"]["file_count"],
        "current_model": result["bundle"]["institution_scorecard"]["current_operating_model"]["model_id"],
        "next_model": result["bundle"]["institution_scorecard"]["next_operating_model"]["model_id"],
    })
    return 0


def cmd_demo(args: argparse.Namespace) -> int:
    result = create_demo(args.out)
    bundle = result["bundle"]
    _print({
        "system": SYSTEM_NAME,
        "compile_id": bundle["compile_id"],
        "content_digest": bundle["content_digest"],
        "out_dir": result["out_dir"],
        "signals": bundle["signal_map"]["signal_count"],
        "assets": bundle["asset_map"]["asset_count"],
        "opportunities": len(bundle["opportunity_radar"]["records"]),
        "selected_portfolio_items": len(bundle["portfolio"]["selected"]),
        "current_model": bundle["institution_scorecard"]["current_operating_model"]["model_id"],
        "next_model": bundle["institution_scorecard"]["next_operating_model"]["model_id"],
        "verification": result["verification"],
    })
    return 0


def cmd_verify(args: argparse.Namespace) -> int:
    result = verify_output(args.out)
    _print(result)
    return 0 if result["valid"] else 1


def cmd_radar(args: argparse.Namespace) -> int:
    bundle = read_json(args.bundle)
    rows = bundle["opportunity_radar"]["records"][: args.limit]
    _print({"radar_id": bundle["opportunity_radar"]["radar_id"], "records": rows})
    return 0


def cmd_portfolio(args: argparse.Namespace) -> int:
    _print(read_json(args.bundle)["portfolio"])
    return 0


def cmd_transition(args: argparse.Namespace) -> int:
    _print(read_json(args.bundle)["transition_plan"])
    return 0


def cmd_mandates(args: argparse.Namespace) -> int:
    registry = read_json(args.bundle)["agent_mandates"]
    if args.role:
        records = [row for row in registry["records"] if row["role_id"] == args.role]
        if not records:
            raise ValueError(f"Unknown role: {args.role}")
        _print(records[0])
    else:
        _print(registry)
    return 0


def cmd_serve(args: argparse.Namespace) -> int:
    serve(args.out, host=args.host, port=args.port)
    return 0


def cmd_mcp(args: argparse.Namespace) -> int:
    run_stdio(args.out)
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="institution95", description="DIKWP-INSTITUTION95 individual-run institution opportunity and transition OS")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("doctor", help="Show runtime and authority boundaries")
    p.set_defaults(func=cmd_doctor)

    p = sub.add_parser("compile", help="Compile an individual-run institution workspace")
    p.add_argument("--owner", required=True)
    p.add_argument("--assets", required=True)
    p.add_argument("--signals", required=True)
    p.add_argument("--constraints", required=True)
    p.add_argument("--opportunities", required=True)
    p.add_argument("--lineage")
    p.add_argument("--praxis-bundle")
    p.add_argument("--successor-bundle")
    p.add_argument("--out", required=True)
    p.add_argument("--source-date-epoch")
    p.set_defaults(func=cmd_compile)

    p = sub.add_parser("demo", help="Compile the public demonstration workspace")
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_demo)

    p = sub.add_parser("verify", help="Verify a compiled output directory")
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_verify)

    p = sub.add_parser("radar", help="Show ranked opportunities")
    p.add_argument("--bundle", required=True)
    p.add_argument("--limit", type=int, default=10)
    p.set_defaults(func=cmd_radar)

    p = sub.add_parser("portfolio", help="Show portfolio allocation")
    p.add_argument("--bundle", required=True)
    p.set_defaults(func=cmd_portfolio)

    p = sub.add_parser("transition", help="Show 180-day transition plan")
    p.add_argument("--bundle", required=True)
    p.set_defaults(func=cmd_transition)

    p = sub.add_parser("mandates", help="Show Agent role mandates")
    p.add_argument("--bundle", required=True)
    p.add_argument("--role")
    p.set_defaults(func=cmd_mandates)

    p = sub.add_parser("serve", help="Serve a loopback-only read-only API")
    p.add_argument("--out", required=True)
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=8796)
    p.set_defaults(func=cmd_serve)

    p = sub.add_parser("mcp", help="Run the read-only MCP reference subset over stdio")
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_mcp)
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return int(args.func(args))
    except Exception as exc:
        print(json.dumps({"error": str(exc), "type": type(exc).__name__}, ensure_ascii=False), file=sys.stderr)
        return 2
