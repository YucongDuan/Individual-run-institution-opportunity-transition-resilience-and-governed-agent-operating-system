from __future__ import annotations

from typing import Any

from .utils import stable_id


def build_paid_experiments(opportunity_radar: dict[str, Any]) -> dict[str, Any]:
    records: list[dict[str, Any]] = []
    candidates = [
        row for row in opportunity_radar.get("records", [])
        if not row.get("blocked") and row.get("recommendation") in {"GO_NOW", "PAID_TEST"}
    ][:5]
    for rank, row in enumerate(candidates, start=1):
        duration = int(row.get("pilot_duration_days", 42))
        price_floor = float(row.get("price_floor", 0))
        experiment = {
            "experiment_id": stable_id("experiment", {"opportunity_id": row["opportunity_id"], "rank": rank}, 22),
            "opportunity_id": row["opportunity_id"],
            "name_cn": row["name_cn"],
            "rank": rank,
            "duration_days": duration,
            "funding_gate": {
                "must_be_paid_or_sponsored": True,
                "price_floor": price_floor,
                "written_scope_required": True,
                "deposit_or_purchase_order_required": bool(price_floor > 0),
            },
            "hypothesis": row.get("pilot_hypothesis", "A bounded, paid pilot will produce a reusable outcome and evidence asset."),
            "minimum_deliverables": row.get("pilot_deliverables", [
                "written baseline and scope",
                "one reusable system or evidence artifact",
                "outcome measurement",
                "rights and attribution record",
            ]),
            "success_metrics": row.get("success_metrics", [
                {"metric": "buyer_acceptance", "threshold": 1, "unit": "signed paid pilot"},
                {"metric": "reusable_asset_created", "threshold": 1, "unit": "asset"},
                {"metric": "unpaid_scope_creep", "threshold": 0, "unit": "events"},
            ]),
            "stop_conditions": row.get("stop_conditions", [
                "No budget owner or written scope",
                "Commercial or identity rights remain unclear",
                "Custom work cannot be converted into a reusable asset",
            ]),
            "external_action_authority": 0,
            "status": "DRAFT_REQUIRES_NAMED_APPROVAL",
        }
        records.append(experiment)
    return {
        "experiment_register_id": stable_id("experiment-register", records, 24),
        "records": records,
        "automatic_execution_authority": 0,
        "selection_rule": "Every opportunity begins as a bounded paid or sponsored experiment with prewritten success and stop conditions.",
    }
