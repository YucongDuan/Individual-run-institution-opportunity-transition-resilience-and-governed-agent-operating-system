from __future__ import annotations

from typing import Any

from .utils import clamp, normalize_weights, safe_mean, stable_id


BUCKET_LABELS = {
    "cash_engine": "现金引擎",
    "compounding_asset": "复利资产",
    "strategic_option": "战略期权",
    "public_value": "公共价值与信任",
}


def allocation_for_runway(runway_months: float) -> dict[str, float]:
    runway = float(runway_months)
    if runway < 6:
        return {"cash_engine": 0.65, "compounding_asset": 0.20, "strategic_option": 0.05, "public_value": 0.10}
    if runway < 12:
        return {"cash_engine": 0.55, "compounding_asset": 0.25, "strategic_option": 0.10, "public_value": 0.10}
    if runway < 24:
        return {"cash_engine": 0.45, "compounding_asset": 0.30, "strategic_option": 0.15, "public_value": 0.10}
    return {"cash_engine": 0.38, "compounding_asset": 0.32, "strategic_option": 0.20, "public_value": 0.10}


def build_portfolio(
    opportunity_radar: dict[str, Any],
    constraints: dict[str, Any],
    owner: dict[str, Any],
) -> dict[str, Any]:
    assumptions = constraints.get("planning_assumptions", {})
    runway = float(assumptions.get("runway_months", 12))
    weekly_hours = float(assumptions.get("owner_hours_per_week", owner.get("capacity", {}).get("owner_hours_per_week", 40)))
    experimentation_budget = float(assumptions.get("monthly_experiment_budget", 0))
    allocations = allocation_for_runway(runway)
    records = [row for row in opportunity_radar.get("records", []) if not row.get("blocked") and row.get("recommendation") != "REJECT_OR_REDESIGN"]
    by_bucket: dict[str, list[dict[str, Any]]] = {key: [] for key in BUCKET_LABELS}
    for row in records:
        bucket = row.get("portfolio_bucket")
        if bucket in by_bucket:
            by_bucket[bucket].append(row)
    selected: list[dict[str, Any]] = []
    for bucket, share in allocations.items():
        candidates = sorted(by_bucket[bucket], key=lambda row: (-row["strategic_score"], row["opportunity_id"]))
        if not candidates:
            continue
        limit = 2 if bucket in {"cash_engine", "compounding_asset"} else 1
        candidates = candidates[:limit]
        weights = normalize_weights({row["opportunity_id"]: max(0.01, row["strategic_score"]) for row in candidates})
        for row in candidates:
            within = weights[row["opportunity_id"]]
            portfolio_share = share * within
            selected.append({
                "opportunity_id": row["opportunity_id"],
                "name_cn": row["name_cn"],
                "bucket": bucket,
                "bucket_label_cn": BUCKET_LABELS[bucket],
                "strategic_score": row["strategic_score"],
                "portfolio_share": round(portfolio_share, 6),
                "owner_hours_per_week": round(weekly_hours * portfolio_share, 2),
                "monthly_experiment_budget": round(experimentation_budget * portfolio_share, 2),
                "price_floor": row.get("price_floor", 0),
                "business_model": row.get("business_model"),
                "recommendation": row.get("recommendation"),
                "stop_conditions": row.get("stop_conditions", []),
            })
    used = sum(item["portfolio_share"] for item in selected)
    reserve = max(0.0, 1.0 - used)
    concentration = max((item["portfolio_share"] for item in selected), default=0.0)
    return {
        "portfolio_id": stable_id("portfolio", [(i["opportunity_id"], i["portfolio_share"]) for i in selected], 24),
        "runway_months_assumption": runway,
        "bucket_allocations": [{"bucket": key, "label_cn": BUCKET_LABELS[key], "share": value} for key, value in allocations.items()],
        "selected": selected,
        "unallocated_reserve_share": round(reserve, 6),
        "portfolio_share_sum": round(used + reserve, 6),
        "concentration": round(concentration, 4),
        "mean_selected_score": round(safe_mean(item["strategic_score"] for item in selected), 4),
        "guardrails": {
            "one_opportunity_max_share": float(constraints.get("portfolio_guardrails", {}).get("one_opportunity_max_share", 0.40)),
            "one_client_revenue_max_share": float(constraints.get("portfolio_guardrails", {}).get("one_client_revenue_max_share", 0.30)),
            "one_platform_dependency_max_share": float(constraints.get("portfolio_guardrails", {}).get("one_platform_dependency_max_share", 0.35)),
            "public_value_floor": float(constraints.get("portfolio_guardrails", {}).get("public_value_floor", 0.08)),
        },
        "alerts": [
            *(["PORTFOLIO_CONCENTRATION_HIGH"] if concentration > float(constraints.get("portfolio_guardrails", {}).get("one_opportunity_max_share", 0.40)) else []),
            *(["RUNWAY_CRITICAL_PRIORITIZE_CASH"] if runway < 6 else []),
            *(["RUNWAY_TIGHT_LIMIT_LONG_HORIZON_RESEARCH"] if 6 <= runway < 12 else []),
        ],
        "boundary": "Planning assumptions are not assertions about the owner's actual finances. Replace them before deployment.",
    }
