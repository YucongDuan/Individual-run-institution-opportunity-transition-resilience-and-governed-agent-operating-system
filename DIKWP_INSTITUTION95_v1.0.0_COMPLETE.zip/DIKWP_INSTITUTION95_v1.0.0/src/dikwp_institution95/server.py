from __future__ import annotations

from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from .utils import ensure_loopback, read_json


ROUTES = {
    "/bundle": "institution_bundle.json",
    "/opportunities": "opportunity_radar.json",
    "/portfolio": "portfolio.json",
    "/transition": "transition_plan_180_days.json",
    "/scorecard": "institution_scorecard.json",
}


def _governance(out: Path) -> dict[str, Any]:
    return {
        "ai_transparency_manifest": read_json(out / "ai_transparency_manifest.json"),
        "burden_firewall": read_json(out / "burden_firewall.json"),
        "agent_mandates": read_json(out / "agent_mandates.json"),
    }


def serve(output_dir: str | Path, host: str = "127.0.0.1", port: int = 8796) -> None:
    ensure_loopback(host)
    out = Path(output_dir).resolve()
    if not (out / "institution_bundle.json").is_file():
        raise FileNotFoundError(f"No compiled bundle in {out}")

    class Handler(BaseHTTPRequestHandler):
        def _send(self, status: int, payload: Any) -> None:
            data = json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(data)

        def do_GET(self) -> None:  # noqa: N802
            path = urlparse(self.path).path
            if path == "/health":
                self._send(200, {"status": "ok", "read_only": True, "automatic_external_action_authority": 0})
                return
            if path == "/governance":
                self._send(200, _governance(out))
                return
            if path in ROUTES:
                self._send(200, read_json(out / ROUTES[path]))
                return
            self._send(404, {"error": "not_found", "path": path})

        def do_POST(self) -> None:  # noqa: N802
            self._send(405, {"error": "read_only_reference_server", "automatic_external_action_authority": 0})

        def log_message(self, fmt: str, *args: Any) -> None:
            return

    ThreadingHTTPServer((host, int(port)), Handler).serve_forever()
