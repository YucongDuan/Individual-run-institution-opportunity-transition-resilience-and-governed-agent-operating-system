from __future__ import annotations

from typing import Any

from .utils import clamp, lexical_tags, safe_mean, stable_id


RIGHTS_MULTIPLIER = {
    "clear_owned": 1.0,
    "clear_licensed": 0.9,
    "public_with_attribution": 0.78,
    "mixed_review_required": 0.58,
    "unclear": 0.32,
    "blocked": 0.0,
}


def validate_asset(asset: dict[str, Any]) -> None:
    required = {"asset_id", "name", "asset_type", "tags", "maturity", "uniqueness", "evidence_strength", "rights_status"}
    missing = sorted(required - set(asset))
    if missing:
        raise ValueError(f"Asset missing required fields: {missing}")
    if asset["rights_status"] not in RIGHTS_MULTIPLIER:
        raise ValueError(f"Unknown rights_status: {asset['rights_status']}")
    for key in ("maturity", "uniqueness", "evidence_strength"):
        if not 0 <= float(asset[key]) <= 1:
            raise ValueError(f"{key} must be between 0 and 1")


def score_asset(asset: dict[str, Any]) -> dict[str, Any]:
    validate_asset(asset)
    rights = RIGHTS_MULTIPLIER[asset["rights_status"]]
    transferability = clamp(asset.get("transferability", 0.5))
    monetizability = clamp(asset.get("monetizability", 0.5))
    public_value = clamp(asset.get("public_value", 0.5))
    owner_dependency = clamp(asset.get("owner_dependency", 0.5))
    compounding = clamp(
        0.20 * float(asset["maturity"])
        + 0.21 * float(asset["uniqueness"])
        + 0.18 * float(asset["evidence_strength"])
        + 0.16 * rights
        + 0.11 * transferability
        + 0.09 * monetizability
        + 0.05 * public_value
        - 0.10 * owner_dependency
    )
    return {
        **asset,
        "tags": sorted(lexical_tags(asset.get("tags", []))),
        "rights_multiplier": round(rights, 4),
        "compounding_potential": round(compounding, 4),
        "record_id": stable_id("asset", {"asset_id": asset["asset_id"], "rights": rights}, 20),
    }


def build_asset_map(assets: list[dict[str, Any]]) -> dict[str, Any]:
    seen: set[str] = set()
    records: list[dict[str, Any]] = []
    for asset in assets:
        aid = str(asset.get("asset_id", ""))
        if aid in seen:
            raise ValueError(f"Duplicate asset_id: {aid}")
        seen.add(aid)
        records.append(score_asset(asset))
    records.sort(key=lambda item: (-item["compounding_potential"], item["asset_id"]))
    return {
        "asset_count": len(records),
        "records": records,
        "summary": {
            "mean_maturity": round(safe_mean(float(a["maturity"]) for a in records), 4),
            "mean_uniqueness": round(safe_mean(float(a["uniqueness"]) for a in records), 4),
            "mean_evidence_strength": round(safe_mean(float(a["evidence_strength"]) for a in records), 4),
            "mean_rights_readiness": round(safe_mean(float(a["rights_multiplier"]) for a in records), 4),
            "mean_compounding_potential": round(safe_mean(float(a["compounding_potential"]) for a in records), 4),
            "blocked_assets": sum(1 for a in records if a["rights_status"] == "blocked"),
            "mixed_or_unclear_assets": sum(1 for a in records if a["rights_status"] in {"mixed_review_required", "unclear"}),
        },
        "boundary": "Asset visibility does not create commercial, identity, endorsement or representation rights.",
    }
