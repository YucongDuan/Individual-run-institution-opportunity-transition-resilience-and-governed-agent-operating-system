from __future__ import annotations

from typing import Any

from .utils import clamp, lexical_tags, normalize_weights, safe_mean, stable_id, weighted_mean


def _matched_assets(template: dict[str, Any], assets: list[dict[str, Any]]) -> list[dict[str, Any]]:
    required = lexical_tags(template.get("required_tags", []))
    optional = lexical_tags(template.get("optional_tags", []))
    records: list[dict[str, Any]] = []
    for asset in assets:
        tags = lexical_tags(asset.get("tags", []))
        required_fit = len(required & tags) / len(required) if required else 1.0
        optional_fit = len(optional & tags) / len(optional) if optional else 0.0
        relevance = clamp(0.82 * required_fit + 0.18 * optional_fit)
        if relevance <= 0:
            continue
        quality = clamp(
            0.23 * float(asset.get("maturity", 0.0))
            + 0.22 * float(asset.get("uniqueness", 0.0))
            + 0.18 * float(asset.get("evidence_strength", 0.0))
            + 0.17 * float(asset.get("rights_multiplier", 0.0))
            + 0.10 * float(asset.get("transferability", 0.5))
            + 0.10 * float(asset.get("monetizability", 0.5))
        )
        records.append({
            "asset_id": asset["asset_id"],
            "name": asset["name"],
            "relevance": round(relevance, 4),
            "quality": round(quality, 4),
            "rights_status": asset["rights_status"],
            "contribution": round(relevance * quality, 4),
        })
    return sorted(records, key=lambda row: (-row["contribution"], row["asset_id"]))


def _signal_support(template: dict[str, Any], signal_records: list[dict[str, Any]]) -> tuple[float, list[dict[str, Any]]]:
    dependencies = set(template.get("signal_dependencies", []))
    rows: list[dict[str, Any]] = []
    for signal in signal_records:
        if signal["signal_id"] not in dependencies:
            continue
        value = float(signal.get("strategic_significance", 0.0))
        rows.append({"signal_id": signal["signal_id"], "support": round(value, 4)})
    return safe_mean(row["support"] for row in rows), rows


def _scenario_robustness(template: dict[str, Any], scenario_records: list[dict[str, Any]]) -> tuple[float, float, list[dict[str, Any]]]:
    payoff_map = template.get("scenario_payoffs", {})
    rows: list[dict[str, Any]] = []
    for scenario in scenario_records:
        payoff = clamp(payoff_map.get(scenario["scenario_id"], 0.35))
        weight = float(scenario.get("stress_weight", 0.0))
        rows.append({
            "scenario_id": scenario["scenario_id"],
            "stress_weight": round(weight, 6),
            "payoff": round(payoff, 4),
            "weighted_payoff": round(weight * payoff, 6),
        })
    weighted = sum(row["weighted_payoff"] for row in rows)
    worst = min((row["payoff"] for row in rows), default=0.0)
    return clamp(weighted), clamp(worst), rows


def _runway_fit(template: dict[str, Any], constraints: dict[str, Any]) -> float:
    sales_cycle = max(1, int(template.get("sales_cycle_days", 60)))
    delivery_cycle = max(1, int(template.get("delivery_cycle_days", 45)))
    runway_months = max(0.1, float(constraints.get("planning_assumptions", {}).get("runway_months", 12)))
    available_days = runway_months * 30
    ratio = available_days / (sales_cycle + delivery_cycle)
    return clamp(ratio / 2.0)


def _rights_readiness(matched: list[dict[str, Any]]) -> float:
    if not matched:
        return 0.0
    status = {
        "clear_owned": 1.0,
        "clear_licensed": 0.9,
        "public_with_attribution": 0.78,
        "mixed_review_required": 0.58,
        "unclear": 0.32,
        "blocked": 0.0,
    }
    return weighted_mean(
        ((status.get(row["rights_status"], 0.0), max(0.01, float(row["contribution"]))) for row in matched),
        default=0.0,
    )


def score_opportunity(
    template: dict[str, Any],
    *,
    asset_records: list[dict[str, Any]],
    signal_records: list[dict[str, Any]],
    scenario_records: list[dict[str, Any]],
    constraints: dict[str, Any],
) -> dict[str, Any]:
    required = {"opportunity_id", "name_cn", "portfolio_bucket", "required_tags", "business_model"}
    missing = sorted(required - set(template))
    if missing:
        raise ValueError(f"Opportunity missing required fields: {missing}")
    matched = _matched_assets(template, asset_records)
    asset_fit = clamp(safe_mean(row["contribution"] for row in matched[:5]))
    signal_fit, signal_rows = _signal_support(template, signal_records)
    scenario_mean, scenario_worst, scenario_rows = _scenario_robustness(template, scenario_records)
    rights_readiness = _rights_readiness(matched)
    runway_fit = _runway_fit(template, constraints)
    defensibility = clamp(template.get("defensibility", 0.5))
    cash_speed = clamp(template.get("cash_speed", 0.5))
    recurring = clamp(template.get("recurring_revenue", 0.5))
    public_value = clamp(template.get("public_value", 0.5))
    reversibility = clamp(template.get("reversibility", 0.7))
    evidence_readiness = clamp(template.get("evidence_readiness", 0.5))
    owner_dependency = clamp(template.get("owner_dependency", 0.5))
    platform_dependency = clamp(template.get("platform_dependency", 0.4))
    rights_risk = clamp(template.get("rights_risk", 0.3))
    free_custom_risk = clamp(template.get("free_customization_risk", 0.4))
    regulatory_risk = clamp(template.get("regulatory_risk", 0.3))
    concentration_risk = clamp(template.get("concentration_risk", 0.3))

    opportunity_value = (
        0.18 * asset_fit
        + 0.13 * signal_fit
        + 0.13 * scenario_mean
        + 0.08 * scenario_worst
        + 0.10 * defensibility
        + 0.08 * cash_speed
        + 0.07 * recurring
        + 0.06 * public_value
        + 0.05 * reversibility
        + 0.05 * evidence_readiness
        + 0.04 * rights_readiness
        + 0.03 * runway_fit
    )
    risk_penalty = (
        0.07 * owner_dependency
        + 0.05 * platform_dependency
        + 0.08 * rights_risk * (1.0 - rights_readiness)
        + 0.06 * free_custom_risk
        + 0.04 * regulatory_risk
        + 0.04 * concentration_risk
    )
    score = clamp(opportunity_value - risk_penalty + 0.05)

    gates: list[dict[str, Any]] = [
        {"gate": "asset_fit", "passed": asset_fit >= float(template.get("min_asset_fit", 0.18)), "value": round(asset_fit, 4)},
        {"gate": "rights_readiness", "passed": rights_readiness >= float(template.get("min_rights_readiness", 0.55)), "value": round(rights_readiness, 4)},
        {"gate": "runway_fit", "passed": runway_fit >= float(template.get("min_runway_fit", 0.25)), "value": round(runway_fit, 4)},
        {"gate": "paid_boundary", "passed": bool(template.get("price_floor", 0) > 0 or template.get("funding_model") in {"sponsorship", "grant", "license"}), "value": template.get("price_floor", 0)},
        {"gate": "external_action_not_required", "passed": not bool(template.get("requires_unsupervised_external_action", False)), "value": not bool(template.get("requires_unsupervised_external_action", False))},
    ]
    blocked = any(not gate["passed"] for gate in gates)
    if blocked or score < 0.42:
        recommendation = "REJECT_OR_REDESIGN"
    elif score >= 0.70 and cash_speed >= 0.55:
        recommendation = "GO_NOW"
    elif score >= 0.58:
        recommendation = "PAID_TEST"
    else:
        recommendation = "WATCH"

    return {
        **template,
        "opportunity_record_id": stable_id("opportunity", {"id": template["opportunity_id"], "score": round(score, 6)}, 22),
        "matched_assets": matched[:8],
        "supporting_signals": signal_rows,
        "scenario_analysis": scenario_rows,
        "dimensions": {
            "asset_fit": round(asset_fit, 4),
            "signal_fit": round(signal_fit, 4),
            "scenario_weighted_robustness": round(scenario_mean, 4),
            "scenario_worst_case": round(scenario_worst, 4),
            "defensibility": round(defensibility, 4),
            "cash_speed": round(cash_speed, 4),
            "recurring_revenue": round(recurring, 4),
            "public_value": round(public_value, 4),
            "reversibility": round(reversibility, 4),
            "evidence_readiness": round(evidence_readiness, 4),
            "rights_readiness": round(rights_readiness, 4),
            "runway_fit": round(runway_fit, 4),
        },
        "risks": {
            "owner_dependency": round(owner_dependency, 4),
            "platform_dependency": round(platform_dependency, 4),
            "rights_risk": round(rights_risk, 4),
            "free_customization_risk": round(free_custom_risk, 4),
            "regulatory_risk": round(regulatory_risk, 4),
            "concentration_risk": round(concentration_risk, 4),
            "aggregate_penalty": round(risk_penalty, 4),
        },
        "gates": gates,
        "blocked": blocked,
        "strategic_score": round(score, 4),
        "recommendation": recommendation,
        "claim_boundary": "The score is a decision aid under declared assumptions, not a revenue forecast or investment guarantee.",
    }


def build_opportunity_radar(
    templates: list[dict[str, Any]],
    *,
    asset_map: dict[str, Any],
    signal_map: dict[str, Any],
    scenario_ensemble: dict[str, Any],
    constraints: dict[str, Any],
) -> dict[str, Any]:
    seen: set[str] = set()
    records: list[dict[str, Any]] = []
    for template in templates:
        oid = str(template.get("opportunity_id", ""))
        if oid in seen:
            raise ValueError(f"Duplicate opportunity_id: {oid}")
        seen.add(oid)
        records.append(score_opportunity(
            template,
            asset_records=asset_map.get("records", []),
            signal_records=signal_map.get("records", []),
            scenario_records=scenario_ensemble.get("records", []),
            constraints=constraints,
        ))
    records.sort(key=lambda row: (-row["strategic_score"], row["opportunity_id"]))
    recommended = [row["opportunity_id"] for row in records if row["recommendation"] in {"GO_NOW", "PAID_TEST"} and not row["blocked"]]
    distribution = normalize_weights({row["opportunity_id"]: row["strategic_score"] for row in records if not row["blocked"]})
    for row in records:
        row["relative_opportunity_weight"] = round(distribution.get(row["opportunity_id"], 0.0), 6)
    return {
        "radar_id": stable_id("opportunity-radar", [(r["opportunity_id"], r["strategic_score"]) for r in records], 24),
        "records": records,
        "recommended_ids": recommended,
        "go_now_count": sum(1 for row in records if row["recommendation"] == "GO_NOW"),
        "paid_test_count": sum(1 for row in records if row["recommendation"] == "PAID_TEST"),
        "blocked_count": sum(1 for row in records if row["blocked"]),
        "selection_rule": "Select robust, paid, rights-clean and reversible opportunities; do not maximize raw score by transferring unpaid burden to the owner.",
    }
