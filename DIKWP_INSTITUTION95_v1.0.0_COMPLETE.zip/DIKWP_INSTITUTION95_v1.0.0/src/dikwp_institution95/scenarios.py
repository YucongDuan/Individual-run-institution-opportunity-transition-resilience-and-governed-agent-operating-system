from __future__ import annotations

from typing import Any

from .utils import normalize_weights, stable_id


SCENARIO_REGISTRY: list[dict[str, Any]] = [
    {
        "scenario_id": "augmented_professionalism",
        "name_cn": "增强型专业社会",
        "name_en": "Augmented Professionalism",
        "base_weight": 0.18,
        "thesis": "AI主要重组任务与专业流程，可信专家仍保留最终判断、关系和责任。",
        "opportunities": ["productized_service", "expert_assurance", "training"],
        "failure_risks": ["owner_bottleneck", "incrementalism", "underpricing"],
        "early_indicators": ["AI adoption rises without broad headcount collapse", "buyers pay for accountable human review"],
    },
    {
        "scenario_id": "cognitive_price_collapse",
        "name_cn": "认知劳动价格坍塌",
        "name_en": "Cognitive Price Collapse",
        "base_weight": 0.17,
        "thesis": "通用分析、写作、翻译、代码和初级咨询快速商品化，按小时出售知识的价格被压缩。",
        "opportunities": ["proprietary_evidence", "outcome_data", "licensing", "institutional_trust"],
        "failure_risks": ["hourly_service_dependence", "generic_content", "free_customization"],
        "early_indicators": ["falling price for routine cognitive deliverables", "rapid model substitution"],
    },
    {
        "scenario_id": "agent_protocol_economy",
        "name_cn": "Agent协议经济",
        "name_en": "Agent Protocol Economy",
        "base_weight": 0.18,
        "thesis": "Agent通过标准协议发现、调用、组合和结算专业能力，机构边界从网页与雇员转向可验证能力接口。",
        "opportunities": ["mcp_service", "a2a_service", "capability_licensing", "machine_readable_governance"],
        "failure_risks": ["invisible_brand", "weak_authorization", "unmetered_usage"],
        "early_indicators": ["MCP/A2A production adoption", "agent procurement of external services"],
    },
    {
        "scenario_id": "trust_regulation_premium",
        "name_cn": "可信与合规溢价",
        "name_en": "Trust and Regulation Premium",
        "base_weight": 0.17,
        "thesis": "合成内容、身份冒用和自动决策风险提升，使来源、授权、AI披露、人工复核和责任链成为付费能力。",
        "opportunities": ["assurance", "audit", "provenance", "ai_transparency", "rights_governance"],
        "failure_risks": ["compliance_debt", "identity_ambiguity", "unreviewed_public_content"],
        "early_indicators": ["mandatory AI interaction disclosure", "buyers request provenance and review records"],
    },
    {
        "scenario_id": "platform_enclosure",
        "name_cn": "平台封闭与流量租金",
        "name_en": "Platform Enclosure",
        "base_weight": 0.15,
        "thesis": "少数模型、商店、社交平台和支付渠道控制分发，个人机构面临封号、抽成、排序和数据锁定。",
        "opportunities": ["owned_audience", "portable_identity", "multi_channel_distribution", "open_protocols"],
        "failure_risks": ["single_platform_concentration", "audience_rent", "closed_model_dependency"],
        "early_indicators": ["rising platform fees", "API restrictions", "algorithmic reach volatility"],
    },
    {
        "scenario_id": "shock_fragmentation",
        "name_cn": "冲击、碎片化与地方网络",
        "name_en": "Shock Fragmentation and Local Networks",
        "base_weight": 0.08,
        "thesis": "地缘、监管、供应链或经济冲击使跨境协作更不稳定，书面协议、冗余渠道和可信小网络的重要性上升。",
        "opportunities": ["federated_network", "local_partners", "offline_continuity", "cash_resilience"],
        "failure_risks": ["cross_border_single_point", "long_receivables", "fragile_cloud_dependency"],
        "early_indicators": ["cross-border service restrictions", "payment or cloud disruption"],
    },
    {
        "scenario_id": "public_value_rebundling",
        "name_cn": "公共价值与新型制度重组",
        "name_en": "Public-Value Rebundling",
        "base_weight": 0.07,
        "thesis": "知识、教育、研究与公共治理通过赞助、基金、标准、开放基础设施和使命型商业重新组合。",
        "opportunities": ["sponsored_open_source", "standards", "public_education", "mission_licensing"],
        "failure_risks": ["grant_dependence", "mission_drift", "unfunded_public_burden"],
        "early_indicators": ["sponsor-backed open infrastructure", "procurement for public-interest AI"],
    },
]


def scenario_registry() -> list[dict[str, Any]]:
    return [dict(item) for item in SCENARIO_REGISTRY]


def build_scenario_ensemble(signal_map: dict[str, Any]) -> dict[str, Any]:
    raw: dict[str, float] = {item["scenario_id"]: float(item["base_weight"]) for item in SCENARIO_REGISTRY}
    signal_support: dict[str, list[dict[str, Any]]] = {item["scenario_id"]: [] for item in SCENARIO_REGISTRY}
    for signal in signal_map.get("records", []):
        significance = float(signal.get("strategic_significance", 0.0))
        for scenario_id, support in (signal.get("scenario_support") or {}).items():
            if scenario_id not in raw:
                continue
            contribution = significance * float(support) * 0.18
            raw[scenario_id] += max(0.0, contribution)
            signal_support[scenario_id].append({
                "signal_id": signal["signal_id"],
                "support": round(float(support), 4),
                "weighted_contribution": round(contribution, 4),
            })
    weights = normalize_weights(raw)
    records: list[dict[str, Any]] = []
    for item in SCENARIO_REGISTRY:
        sid = item["scenario_id"]
        records.append({
            **item,
            "stress_weight": round(weights[sid], 6),
            "signal_support": sorted(signal_support[sid], key=lambda row: (-row["weighted_contribution"], row["signal_id"])),
        })
    records.sort(key=lambda item: (-item["stress_weight"], item["scenario_id"]))
    return {
        "ensemble_id": stable_id("scenario-ensemble", [(r["scenario_id"], r["stress_weight"]) for r in records], 24),
        "records": records,
        "weight_sum": round(sum(r["stress_weight"] for r in records), 6),
        "interpretation_boundary": (
            "Stress weights allocate attention across mutually non-isomorphic futures. "
            "They are not calibrated event probabilities and must not be reported as forecasts."
        ),
        "retirement_rule": "Retire or reweight a scenario when its distinguishing indicators repeatedly fail or a new non-isomorphic model explains outcomes better.",
    }
