from __future__ import annotations

from typing import Any

from .utils import clamp, safe_mean, stable_id


EPISTEMIC_MULTIPLIER = {
    "official_current_rule": 1.00,
    "official_statistics": 0.96,
    "official_study": 0.90,
    "primary_technical_specification": 0.92,
    "source_grounded_inference": 0.72,
    "working_hypothesis": 0.52,
    "speculation": 0.28,
}

HORIZON_URGENCY = {
    "0-6m": 1.00,
    "6-18m": 0.84,
    "18-36m": 0.66,
    "3-7y": 0.46,
    "7y+": 0.28,
}


def validate_signal(signal: dict[str, Any]) -> None:
    required = {"signal_id", "title", "category", "epistemic_status", "impact", "confidence", "exposure", "horizon"}
    missing = sorted(required - set(signal))
    if missing:
        raise ValueError(f"Signal missing required fields: {missing}")
    for key in ("impact", "confidence", "exposure"):
        value = float(signal[key])
        if not 0 <= value <= 1:
            raise ValueError(f"{key} must be between 0 and 1")
    if signal["epistemic_status"] not in EPISTEMIC_MULTIPLIER:
        raise ValueError(f"Unknown epistemic_status: {signal['epistemic_status']}")
    if signal["horizon"] not in HORIZON_URGENCY:
        raise ValueError(f"Unknown horizon: {signal['horizon']}")


def score_signal(signal: dict[str, Any]) -> dict[str, Any]:
    validate_signal(signal)
    evidence = EPISTEMIC_MULTIPLIER[signal["epistemic_status"]]
    urgency = HORIZON_URGENCY[signal["horizon"]]
    raw = (
        0.34 * float(signal["impact"])
        + 0.24 * float(signal["confidence"])
        + 0.20 * float(signal["exposure"])
        + 0.14 * urgency
        + 0.08 * evidence
    )
    score = clamp(raw * (0.70 + 0.30 * evidence))
    actionability = clamp(
        0.38 * score
        + 0.24 * urgency
        + 0.20 * float(signal.get("controllability", 0.5))
        + 0.18 * float(signal.get("observability", 0.5))
    )
    return {
        **signal,
        "evidence_multiplier": round(evidence, 4),
        "urgency_multiplier": round(urgency, 4),
        "strategic_significance": round(score, 4),
        "actionability": round(actionability, 4),
        "record_id": stable_id("signal", {"signal_id": signal["signal_id"], "score": round(score, 6)}, 20),
    }


def build_signal_map(signals: list[dict[str, Any]]) -> dict[str, Any]:
    ids: set[str] = set()
    records: list[dict[str, Any]] = []
    for signal in signals:
        if signal.get("signal_id") in ids:
            raise ValueError(f"Duplicate signal_id: {signal.get('signal_id')}")
        ids.add(str(signal.get("signal_id")))
        records.append(score_signal(signal))
    records.sort(key=lambda item: (-item["strategic_significance"], item["signal_id"]))
    by_category: dict[str, list[float]] = {}
    for item in records:
        by_category.setdefault(item["category"], []).append(float(item["strategic_significance"]))
    category_summary = [
        {"category": category, "mean_significance": round(safe_mean(values), 4), "signal_count": len(values)}
        for category, values in sorted(by_category.items())
    ]
    return {
        "signal_count": len(records),
        "records": records,
        "category_summary": category_summary,
        "epistemic_boundary": (
            "Scores prioritize attention; they are not probabilities that a future event will occur. "
            "Official facts, source-grounded inferences and working hypotheses remain separated."
        ),
    }
