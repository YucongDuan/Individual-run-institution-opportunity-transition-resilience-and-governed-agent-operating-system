from __future__ import annotations

import json
from pathlib import Path
import sys
from typing import Any

from .utils import read_json


def _response(req_id: Any, result: Any = None, error: Any = None) -> dict[str, Any]:
    payload = {"jsonrpc": "2.0", "id": req_id}
    if error is not None:
        payload["error"] = error
    else:
        payload["result"] = result
    return payload


def run_stdio(output_dir: str | Path) -> None:
    out = Path(output_dir)
    manifest = read_json(out / "mcp_tool_manifest.json")
    bundle = read_json(out / "institution_bundle.json")
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            req = json.loads(line)
            method = req.get("method")
            req_id = req.get("id")
            params = req.get("params") or {}
            if method == "tools/list":
                result = {"tools": manifest["tools"]}
            elif method == "tools/call":
                name = params.get("name")
                args = params.get("arguments") or {}
                if name == "institution.summary":
                    result = {
                        "scorecard": bundle["institution_scorecard"],
                        "selected_opportunities": bundle["portfolio"]["selected"],
                        "governance": bundle["governance"],
                    }
                elif name == "opportunity.radar":
                    limit = max(1, min(20, int(args.get("limit", 10))))
                    result = {**bundle["opportunity_radar"], "records": bundle["opportunity_radar"]["records"][:limit]}
                elif name == "portfolio.plan":
                    result = bundle["portfolio"]
                elif name == "transition.plan":
                    result = bundle["transition_plan"]
                elif name == "governance.manifest":
                    result = {
                        "governance": bundle["governance"],
                        "ai_transparency_manifest": bundle["ai_transparency_manifest"],
                        "burden_firewall": bundle["burden_firewall"],
                    }
                else:
                    raise ValueError(f"Unknown tool: {name}")
            else:
                raise ValueError(f"Unsupported method: {method}")
            payload = _response(req_id, result=result)
        except Exception as exc:  # reference transport keeps errors explicit
            payload = _response(req.get("id") if isinstance(req, dict) else None, error={"code": -32000, "message": str(exc)})
        sys.stdout.write(json.dumps(payload, ensure_ascii=False, sort_keys=True) + "\n")
        sys.stdout.flush()
