from __future__ import annotations

from typing import Any


def build_mcp_manifest() -> dict[str, Any]:
    return {
        "protocol": "Model Context Protocol",
        "profile": "2026-07-28 read-only reference subset",
        "conformance_claim": "reference_subset_not_independently_certified",
        "stateless": True,
        "tools": [
            {
                "name": "institution.summary",
                "description": "Return the operating-model scorecard, governance boundary and selected opportunities.",
                "inputSchema": {"type": "object", "properties": {}, "additionalProperties": False},
            },
            {
                "name": "opportunity.radar",
                "description": "Return ranked opportunity records and gates.",
                "inputSchema": {"type": "object", "properties": {"limit": {"type": "integer", "minimum": 1, "maximum": 20}}, "additionalProperties": False},
            },
            {
                "name": "portfolio.plan",
                "description": "Return time and experiment-budget allocation across cash, compound, option and public-value buckets.",
                "inputSchema": {"type": "object", "properties": {}, "additionalProperties": False},
            },
            {
                "name": "transition.plan",
                "description": "Return the 180-day transition phases and triggers.",
                "inputSchema": {"type": "object", "properties": {}, "additionalProperties": False},
            },
            {
                "name": "governance.manifest",
                "description": "Return AI transparency, burden firewall and authority constraints.",
                "inputSchema": {"type": "object", "properties": {}, "additionalProperties": False},
            },
        ],
        "write_tools": [],
        "automatic_external_action_authority": 0,
    }


def build_a2a_agent_card() -> dict[str, Any]:
    return {
        "name": "DIKWP-INSTITUTION95 Opportunity and Transition Agent",
        "description": "A read-only planning agent for individual-run institutions, with opportunity radar, portfolio stress tests, transition plans and governance boundaries.",
        "version": "1.0.0",
        "protocolVersion": "1.0",
        "url": "http://127.0.0.1:8796/a2a",
        "preferredTransport": "HTTP+JSON",
        "capabilities": {"streaming": False, "pushNotifications": False, "stateTransitionHistory": False},
        "skills": [
            {"id": "opportunity-radar", "name": "Opportunity Radar", "description": "Rank paid, rights-clean and reversible opportunities across plural futures.", "tags": ["strategy", "opportunity", "portfolio"]},
            {"id": "institution-transition", "name": "Institution Transition", "description": "Plan transition from owner-dependent expert work toward a governed micro-institution.", "tags": ["operating-model", "agents", "resilience"]},
            {"id": "governance-audit", "name": "Governance Audit", "description": "Expose authority, AI transparency and burden-transfer boundaries.", "tags": ["governance", "rights", "transparency"]},
        ],
        "securitySchemes": {},
        "security": [],
        "authentication_boundary": "Reference local read-only card. Production authentication must be added outside the demo.",
    }


def build_openapi() -> dict[str, Any]:
    paths: dict[str, Any] = {}
    endpoints = {
        "/health": "Service health and authority boundary",
        "/bundle": "Full compiled institution bundle",
        "/opportunities": "Opportunity radar",
        "/portfolio": "Portfolio plan",
        "/transition": "Transition plan",
        "/scorecard": "Institution scorecard",
        "/governance": "Governance and AI transparency manifests",
    }
    for path, summary in endpoints.items():
        paths[path] = {
            "get": {
                "summary": summary,
                "responses": {"200": {"description": "JSON response"}},
            }
        }
    return {
        "openapi": "3.1.0",
        "info": {
            "title": "DIKWP-INSTITUTION95 Read-only API",
            "version": "1.0.0",
            "description": "Loopback-only reference API. No external actions, payments or identity operations.",
        },
        "servers": [{"url": "http://127.0.0.1:8796"}],
        "paths": paths,
    }
