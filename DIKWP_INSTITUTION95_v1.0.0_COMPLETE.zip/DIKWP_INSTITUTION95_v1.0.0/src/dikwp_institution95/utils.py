from __future__ import annotations

import hashlib
import json
import math
import os
from pathlib import Path
import tempfile
from datetime import datetime, timezone
from typing import Any, Iterable


def canonical_json(value: Any) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_obj(value: Any) -> str:
    return sha256_bytes(canonical_json(value))


def stable_id(prefix: str, value: Any, length: int = 24) -> str:
    return f"{prefix}-{sha256_obj(value)[:length]}"


def clamp(value: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, float(value)))


def safe_mean(values: Iterable[float], default: float = 0.0) -> float:
    data = [float(v) for v in values]
    return sum(data) / len(data) if data else float(default)


def weighted_mean(pairs: Iterable[tuple[float, float]], default: float = 0.0) -> float:
    rows = [(float(value), float(weight)) for value, weight in pairs if float(weight) > 0]
    total = sum(weight for _, weight in rows)
    return sum(value * weight for value, weight in rows) / total if total else float(default)


def normalize_weights(items: dict[str, float]) -> dict[str, float]:
    clean = {str(k): max(0.0, float(v)) for k, v in items.items()}
    total = sum(clean.values())
    if total <= 0:
        if not clean:
            return {}
        equal = 1.0 / len(clean)
        return {key: equal for key in clean}
    return {key: value / total for key, value in clean.items()}


def money_round(value: float) -> float:
    return round(float(value) + 1e-12, 2)


def logit(value: float) -> float:
    value = clamp(value, 1e-9, 1 - 1e-9)
    return math.log(value / (1 - value))


def timestamp_iso(source_date_epoch: str | None = None) -> str:
    raw = source_date_epoch or os.environ.get("SOURCE_DATE_EPOCH")
    if raw:
        dt = datetime.fromtimestamp(int(raw), tz=timezone.utc)
    else:
        dt = datetime.now(timezone.utc)
    return dt.replace(microsecond=0).isoformat().replace("+00:00", "Z")


def read_json(path: str | Path) -> Any:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_json(path: str | Path, value: Any) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False) + "\n"
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", delete=False, dir=path.parent, newline="\n") as tmp:
        tmp.write(text)
        tmp_path = Path(tmp.name)
    os.replace(tmp_path, path)


def load_list(path: str | Path, key: str | None = None) -> list[dict[str, Any]]:
    value = read_json(path)
    if key and isinstance(value, dict):
        value = value.get(key, [])
    if not isinstance(value, list):
        raise ValueError(f"Expected a list in {path}")
    if not all(isinstance(item, dict) for item in value):
        raise ValueError(f"Expected an object list in {path}")
    return value


def lexical_tags(value: Any) -> set[str]:
    if value is None:
        return set()
    if isinstance(value, str):
        chunks = value.replace("/", " ").replace(",", " ").replace("，", " ").split()
        return {chunk.strip().lower() for chunk in chunks if chunk.strip()}
    if isinstance(value, (list, tuple, set)):
        out: set[str] = set()
        for item in value:
            out.update(lexical_tags(item))
        return out
    return {str(value).strip().lower()} if str(value).strip() else set()


def overlap_score(required: Iterable[str], available: Iterable[str]) -> float:
    req = lexical_tags(list(required))
    have = lexical_tags(list(available))
    if not req:
        return 1.0
    return len(req & have) / len(req)


def ensure_loopback(host: str) -> None:
    if host not in {"127.0.0.1", "localhost", "::1"}:
        raise ValueError("The reference server may bind only to a loopback address")


def public_file_hashes(root: str | Path, exclude: set[str] | None = None) -> list[dict[str, Any]]:
    root = Path(root)
    excluded = exclude or set()
    rows: list[dict[str, Any]] = []
    for path in sorted(p for p in root.rglob("*") if p.is_file()):
        rel = path.relative_to(root).as_posix()
        if rel in excluded or path.name in excluded:
            continue
        data = path.read_bytes()
        rows.append({"path": rel, "sha256": sha256_bytes(data), "bytes": len(data)})
    return rows
