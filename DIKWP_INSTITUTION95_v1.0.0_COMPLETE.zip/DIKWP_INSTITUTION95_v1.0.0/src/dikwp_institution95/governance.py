from __future__ import annotations

from typing import Any

from .utils import stable_id


AGENT_ROLE_REGISTRY: list[dict[str, Any]] = [
    {
        "role_id": "opportunity_scout",
        "name_cn": "机会侦察Agent",
        "purpose": "读取已授权信号，发现市场、政策、技术和合作机会。",
        "allowed_operations": ["signals.read", "signals.classify", "opportunities.draft"],
        "prohibited_operations": ["outreach.send", "contract.accept", "payment.execute", "account.control"],
        "human_gate": "Any external contact or public claim",
    },
    {
        "role_id": "evidence_steward",
        "name_cn": "证据与来源管家Agent",
        "purpose": "维护来源、主张等级、版本、反证和引用闭环。",
        "allowed_operations": ["sources.read", "evidence.map", "claims.audit", "provenance.export"],
        "prohibited_operations": ["source.fabricate", "claim.upgrade_without_evidence", "rights.infer"],
        "human_gate": "Disputed attribution or evidence status",
    },
    {
        "role_id": "product_architect",
        "name_cn": "产品架构Agent",
        "purpose": "把重复专家劳动转为有价格、有范围、可复用的产品。",
        "allowed_operations": ["products.draft", "scope.bound", "pilot.design", "pricing.simulate"],
        "prohibited_operations": ["price.commit", "discount.promise", "free_customization.commit"],
        "human_gate": "Price, scope and buyer commitment",
    },
    {
        "role_id": "proposal_drafter",
        "name_cn": "书面提案Agent",
        "purpose": "生成异步优先的合作、报价和变更单草案。",
        "allowed_operations": ["proposal.draft", "scope.compare", "terms.flag"],
        "prohibited_operations": ["email.send", "calendar.book", "signature.apply", "relationship.impersonate"],
        "human_gate": "Named sender approval before transmission",
    },
    {
        "role_id": "delivery_orchestrator",
        "name_cn": "交付编排Agent",
        "purpose": "协调可重复交付、检查清单、验收和结果回流。",
        "allowed_operations": ["tasks.plan", "artifacts.check", "acceptance.track", "outcomes.record"],
        "prohibited_operations": ["client_system.write", "high_impact_decision.execute"],
        "human_gate": "Any change to client or public systems",
    },
    {
        "role_id": "runway_guardian",
        "name_cn": "现金流与韧性Agent",
        "purpose": "监测跑道、应收、客户集中、平台依赖和无偿劳动。",
        "allowed_operations": ["runway.calculate", "concentration.alert", "scope_creep.detect", "portfolio.simulate"],
        "prohibited_operations": ["bank.access", "payment.execute", "tax.file", "investment.trade"],
        "human_gate": "Financial commitment or legal filing",
    },
    {
        "role_id": "rights_and_transparency_guardian",
        "name_cn": "权利与AI透明Agent",
        "purpose": "检查署名、商用、身份、代表、AI标识和人工复核条件。",
        "allowed_operations": ["rights.check", "ai_label.generate", "voice.verify", "publication.block"],
        "prohibited_operations": ["consent.assume", "identity.clone", "officially_represent"],
        "human_gate": "Rights dispute, identity use or public-interest publication",
    },
    {
        "role_id": "partner_federation_agent",
        "name_cn": "伙伴联邦Agent",
        "purpose": "在最小披露原则下匹配专家、实验室、交付与渠道伙伴。",
        "allowed_operations": ["partner.match", "capability.compare", "contribution.draft"],
        "prohibited_operations": ["partnership.bind", "credit_reallocate", "private_data_disclose"],
        "human_gate": "Sharing identity, private data or commercial terms",
    },
    {
        "role_id": "continuity_steward",
        "name_cn": "机构连续与继任Agent",
        "purpose": "维护档案、停机、继任和创始人缺席时的受控连续性。",
        "allowed_operations": ["archive.verify", "continuity.simulate", "succession.check", "handoff.draft"],
        "prohibited_operations": ["incapacity.determine", "death.determine", "successor.activate", "identity.assume"],
        "human_gate": "All succession or incapacity decisions",
    },
]


def build_agent_mandates(owner: dict[str, Any], constraints: dict[str, Any]) -> dict[str, Any]:
    default_budget = int(constraints.get("agent_governance", {}).get("default_max_operations_per_day", 50))
    records: list[dict[str, Any]] = []
    for role in AGENT_ROLE_REGISTRY:
        records.append({
            **role,
            "mandate_id": stable_id("mandate", {"owner": owner["owner_id"], "role": role["role_id"]}, 22),
            "principal": owner["owner_id"],
            "validity": "template_until_named_owner_approval",
            "max_operations_per_day": default_budget,
            "external_action_authority": 0,
            "payment_authority": 0,
            "identity_authority": 0,
            "self_modification_authority": 0,
            "audit_required": True,
            "revocable": True,
            "status": "DRAFT_NOT_ACTIVATED",
        })
    return {
        "mandate_registry_id": stable_id("mandate-registry", records, 24),
        "records": records,
        "final_authority": "named_owner_or_valid_written_delegate",
        "automatic_external_action_authority": 0,
    }


def build_ai_transparency_manifest(owner: dict[str, Any], constraints: dict[str, Any]) -> dict[str, Any]:
    jurisdictions = owner.get("jurisdictions", [])
    return {
        "manifest_id": stable_id("ai-transparency", {"owner": owner["owner_id"], "jurisdictions": jurisdictions}, 22),
        "owner_id": owner["owner_id"],
        "jurisdictions": jurisdictions,
        "direct_interaction_notice": {
            "required": True,
            "default_notice_cn": "您正在与受治理的AI辅助系统交互；重要判断、合同、身份与权利事项须由具名人员确认。",
            "default_notice_en": "You are interacting with a governed AI-assisted system; material decisions, contracts, identity and rights require named human confirmation.",
        },
        "synthetic_content_marking": {
            "machine_readable_mark_required": True,
            "visible_label_for_public_interest_content": True,
            "marking_profile": "reference_manifest_not_a_certified_compliance_solution",
        },
        "human_review": {
            "public_interest_text": "required_unless_an_applicable_exception_is_documented",
            "high_impact_decisions": "always_required",
            "commercial_commitments": "always_required",
            "identity_or_voice_use": "always_required_and_separately_authorized",
        },
        "prohibited_defaults": [
            "Do not conceal that the counterparty is interacting with AI when disclosure is required.",
            "Do not publish deepfakes or cloned voice without explicit authority and visible disclosure.",
            "Do not present successor or Agent-generated content as the owner's personal statement.",
            "Do not infer consent from silence, politeness, attendance or prior free help.",
        ],
        "automatic_compliance_certificate": None,
        "legal_boundary": "This manifest helps operationalize transparency. It is not legal advice or a jurisdiction-wide compliance certificate.",
    }


def build_burden_firewall(owner: dict[str, Any], constraints: dict[str, Any]) -> dict[str, Any]:
    rules = [
        {
            "rule_id": "no_unpaid_custom_prototype",
            "condition": "A counterparty requests a tailored prototype, report, integration or workshop without written budget and scope.",
            "response": "Offer the public sandbox or a paid bounded pilot; do not continue custom work.",
        },
        {
            "rule_id": "acknowledgement_not_authorization",
            "condition": "The counterparty is polite, attends a meeting, says they understand, or does not answer pricing.",
            "response": "Treat this as neither purchase, endorsement nor permission; require explicit written authorization.",
        },
        {
            "rule_id": "high_leverage_duty",
            "condition": "A platform, institution, funder or senior actor can impose disproportionate cost or reputational risk.",
            "response": "Require clearer scope, attribution, burden sharing, data boundaries and exit rights from the higher-leverage actor.",
        },
        {
            "rule_id": "credit_and_rights_freeze",
            "condition": "Authorship, contribution, patent, data or identity rights are disputed.",
            "response": "Freeze derivative commercialization and preserve append-only evidence until resolved in writing.",
        },
        {
            "rule_id": "platform_portability",
            "condition": "A platform exceeds the permitted audience, revenue, identity or data concentration threshold.",
            "response": "Export data, build a direct channel and a protocol-neutral interface; do not expand dependence.",
        },
        {
            "rule_id": "public_good_funding",
            "condition": "A project is justified as public good but repeatedly consumes the owner's private time and cash.",
            "response": "Require sponsorship, grant, institutional cost sharing or a capped public-service allocation.",
        },
    ]
    return {
        "firewall_id": stable_id("burden-firewall", {"owner": owner["owner_id"], "rules": rules}, 22),
        "rules": rules,
        "owner_override": True,
        "automatic_commitment_authority": 0,
        "core_stance": "FACTUALLY_OBJECTIVE_RELATIONALLY_PROTECTIVE",
    }


def agent_role_registry() -> list[dict[str, Any]]:
    return [dict(item) for item in AGENT_ROLE_REGISTRY]
