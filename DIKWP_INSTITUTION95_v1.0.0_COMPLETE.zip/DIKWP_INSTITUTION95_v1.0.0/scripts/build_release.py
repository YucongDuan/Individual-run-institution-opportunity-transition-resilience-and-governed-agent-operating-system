from __future__ import annotations

import argparse
from pathlib import Path
import zipfile

EXCLUDE_PARTS = {".git", "__pycache__", ".pytest_cache", ".mypy_cache", "dist", "build"}


def add_tree(zf: zipfile.ZipFile, root: Path, prefix: str, include_outputs: bool) -> None:
    for path in sorted(root.rglob("*")):
        rel = path.relative_to(root)
        if any(part in EXCLUDE_PARTS for part in rel.parts):
            continue
        if not include_outputs and rel.parts and rel.parts[0] in {"outputs", "artifacts"}:
            continue
        if path.is_file() and not path.is_symlink():
            info = zipfile.ZipInfo(f"{prefix}/{rel.as_posix()}")
            info.date_time = (2026, 9, 1, 0, 0, 0)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = (0o644 & 0xFFFF) << 16
            zf.writestr(info, path.read_bytes())


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    parser.add_argument("--out", required=True)
    parser.add_argument("--include-outputs", action="store_true")
    args = parser.parse_args()
    root = Path(args.root).resolve()
    out = Path(args.out).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        add_tree(zf, root, root.name, args.include_outputs)
    print(out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
