from __future__ import annotations

import argparse
import json
from pathlib import Path
import subprocess
import sys


def run(cmd: list[str], cwd: Path) -> dict[str, object]:
    proc = subprocess.run(cmd, cwd=cwd, text=True, capture_output=True, check=False)
    return {"command": cmd, "returncode": proc.returncode, "stdout": proc.stdout[-4000:], "stderr": proc.stderr[-4000:]}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    args = parser.parse_args()
    root = Path(args.root).resolve()
    checks = [
        run([sys.executable, "-m", "unittest", "discover", "-s", "tests", "-v"], root),
        run([sys.executable, "run.py", "doctor"], root),
        run([sys.executable, "run.py", "verify", "--out", "outputs/demo"], root),
    ]
    valid = all(row["returncode"] == 0 for row in checks)
    payload = {"valid": valid, "checks": checks}
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0 if valid else 1


if __name__ == "__main__":
    raise SystemExit(main())
