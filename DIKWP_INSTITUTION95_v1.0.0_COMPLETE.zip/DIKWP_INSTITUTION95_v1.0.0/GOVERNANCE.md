# Project Governance

DIKWP-INSTITUTION95 is an open-source reference system. Code contributions may improve the system, but contribution does not transfer ownership of third-party content, personal identity, patents, trademarks, private memory, endorsement or official representation rights.

## Decision classes

- **Code and documentation:** maintainers review through traceable patches.
- **Security:** privately disclosed issues are triaged before public detail.
- **Personal identity or voice:** requires separate explicit authorization from the relevant person.
- **High-impact deployment:** requires a named human owner, written scope, rollback conditions and applicable professional review.
- **External action, payment and legal status:** outside the authority of the reference release.

The project does not treat silence, politeness, attendance, prior free help or public availability as consent.
