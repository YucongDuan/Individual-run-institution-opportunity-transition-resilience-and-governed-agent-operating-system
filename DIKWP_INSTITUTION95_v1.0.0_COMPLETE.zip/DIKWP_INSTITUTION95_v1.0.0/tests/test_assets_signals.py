from __future__ import annotations

import copy
import unittest

from common import load
from dikwp_institution95.assets import build_asset_map, score_asset, validate_asset
from dikwp_institution95.signals import build_signal_map, score_signal, validate_signal


class AssetSignalTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.assets = load("assets.json")["assets"]
        cls.signals = load("signals.json")["signals"]

    def test_asset_map_count(self):
        self.assertEqual(build_asset_map(self.assets)["asset_count"], len(self.assets))

    def test_asset_map_sorted(self):
        records = build_asset_map(self.assets)["records"]
        self.assertGreaterEqual(records[0]["compounding_potential"], records[-1]["compounding_potential"])

    def test_blocked_rights_zero(self):
        item = copy.deepcopy(self.assets[0])
        item["asset_id"] = "blocked"
        item["rights_status"] = "blocked"
        self.assertEqual(score_asset(item)["rights_multiplier"], 0.0)

    def test_invalid_asset_score_rejected(self):
        item = copy.deepcopy(self.assets[0])
        item["maturity"] = 1.2
        with self.assertRaises(ValueError):
            validate_asset(item)

    def test_duplicate_asset_rejected(self):
        with self.assertRaises(ValueError):
            build_asset_map([self.assets[0], self.assets[0]])

    def test_signal_map_count(self):
        self.assertEqual(build_signal_map(self.signals)["signal_count"], len(self.signals))

    def test_official_signal_high_multiplier(self):
        official = next(s for s in self.signals if s["epistemic_status"] == "official_current_rule")
        self.assertEqual(score_signal(official)["evidence_multiplier"], 1.0)

    def test_hypothesis_lower_multiplier(self):
        hypothesis = next(s for s in self.signals if s["epistemic_status"] == "working_hypothesis")
        self.assertLess(score_signal(hypothesis)["evidence_multiplier"], 0.6)

    def test_invalid_horizon_rejected(self):
        item = copy.deepcopy(self.signals[0])
        item["horizon"] = "tomorrow"
        with self.assertRaises(ValueError):
            validate_signal(item)

    def test_signal_boundary_present(self):
        self.assertIn("not probabilities", build_signal_map(self.signals)["epistemic_boundary"])


if __name__ == "__main__":
    unittest.main()
