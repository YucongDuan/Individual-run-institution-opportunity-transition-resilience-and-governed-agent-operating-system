from __future__ import annotations

import json
from pathlib import Path
import shutil
import tempfile
import unittest

from common import DATA
from dikwp_institution95.compiler import compile_institution, write_manifest
from dikwp_institution95.demo import create_demo
from dikwp_institution95.utils import read_json, write_json
from dikwp_institution95.verify import verify_output


class CompileVerifyTests(unittest.TestCase):
    def compile_once(self, out: Path):
        return compile_institution(
            owner_path=DATA / "owner.json",
            assets_path=DATA / "assets.json",
            signals_path=DATA / "signals.json",
            constraints_path=DATA / "constraints.json",
            opportunities_path=DATA / "opportunities.json",
            lineage_path=DATA / "lineage.json",
            out_dir=out,
            source_date_epoch="1788220800",
        )

    def test_compile_produces_bundle(self):
        with tempfile.TemporaryDirectory() as td:
            result = self.compile_once(Path(td))
            self.assertTrue((Path(td) / "institution_bundle.json").is_file())
            self.assertTrue(result["bundle"]["compile_id"].startswith("institution-"))

    def test_deterministic_compile(self):
        with tempfile.TemporaryDirectory() as a, tempfile.TemporaryDirectory() as b:
            one = self.compile_once(Path(a))["bundle"]
            two = self.compile_once(Path(b))["bundle"]
            self.assertEqual(one["compile_id"], two["compile_id"])
            self.assertEqual(one["content_digest"], two["content_digest"])

    def test_verify_valid(self):
        with tempfile.TemporaryDirectory() as td:
            self.compile_once(Path(td))
            self.assertTrue(verify_output(td)["valid"])

    def test_tampered_bundle_detected(self):
        with tempfile.TemporaryDirectory() as td:
            self.compile_once(Path(td))
            path = Path(td) / "institution_bundle.json"
            bundle = read_json(path)
            bundle["owner"]["display_name"] = "tampered"
            write_json(path, bundle)
            self.assertFalse(verify_output(td)["valid"])

    def test_tampered_dashboard_detected(self):
        with tempfile.TemporaryDirectory() as td:
            self.compile_once(Path(td))
            path = Path(td) / "dashboard.html"
            path.write_text(path.read_text(encoding="utf-8") + "tamper", encoding="utf-8")
            self.assertFalse(verify_output(td)["valid"])

    def test_missing_file_detected(self):
        with tempfile.TemporaryDirectory() as td:
            self.compile_once(Path(td))
            (Path(td) / "portfolio.json").unlink()
            self.assertFalse(verify_output(td)["valid"])

    def test_demo_validation(self):
        with tempfile.TemporaryDirectory() as td:
            result = create_demo(td)
            self.assertTrue(result["verification"]["valid"])
            self.assertTrue((Path(td) / "DEMO_VALIDATION.json").is_file())

    def test_manifest_excludes_itself(self):
        with tempfile.TemporaryDirectory() as td:
            self.compile_once(Path(td))
            manifest = read_json(Path(td) / "MANIFEST.json")
            self.assertNotIn("MANIFEST.json", {row["path"] for row in manifest["files"]})

    def test_manifest_can_be_regenerated(self):
        with tempfile.TemporaryDirectory() as td:
            result = self.compile_once(Path(td))
            manifest = write_manifest(td, result["bundle"]["compile_id"])
            self.assertGreater(manifest["file_count"], 10)

    def test_external_authority_zero(self):
        with tempfile.TemporaryDirectory() as td:
            bundle = self.compile_once(Path(td))["bundle"]
            self.assertEqual(bundle["governance"]["automatic_external_action_authority"], 0)

    def test_claim_boundaries_false(self):
        with tempfile.TemporaryDirectory() as td:
            bundle = self.compile_once(Path(td))["bundle"]
            self.assertTrue(all(value is False or value == 0 for value in bundle["claim_boundaries"].values()))


if __name__ == "__main__":
    unittest.main()
