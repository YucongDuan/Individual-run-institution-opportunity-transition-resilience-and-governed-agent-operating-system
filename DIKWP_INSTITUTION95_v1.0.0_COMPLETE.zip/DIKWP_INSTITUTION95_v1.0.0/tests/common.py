from __future__ import annotations

import json
from pathlib import Path
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

DATA = SRC / "dikwp_institution95" / "data" / "demo"


def load(name: str):
    return json.loads((DATA / name).read_text(encoding="utf-8"))


def tempdir():
    return tempfile.TemporaryDirectory()

_DEMO_CACHE: tuple[Path, Path] | None = None


def demo_paths() -> tuple[Path, Path]:
    global _DEMO_CACHE
    if _DEMO_CACHE is None:
        from dikwp_institution95.demo import create_demo
        out = Path(tempfile.mkdtemp(prefix="institution95-test-demo-"))
        create_demo(out)
        _DEMO_CACHE = (out, out / "institution_bundle.json")
    return _DEMO_CACHE
