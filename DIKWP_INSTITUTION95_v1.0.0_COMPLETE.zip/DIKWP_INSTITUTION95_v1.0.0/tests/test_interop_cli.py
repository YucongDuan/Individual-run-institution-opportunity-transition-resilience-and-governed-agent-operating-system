from __future__ import annotations

import io
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
import threading
import time
import unittest
from urllib.request import Request, urlopen
from urllib.error import HTTPError

from common import ROOT, SRC, demo_paths
from dikwp_institution95.cli import main
from dikwp_institution95.interop import build_a2a_agent_card, build_mcp_manifest, build_openapi
from dikwp_institution95.server import serve
from dikwp_institution95.utils import ensure_loopback, read_json


class InteropCliTests(unittest.TestCase):
    def test_mcp_manifest_is_read_only(self) -> None:
        manifest = build_mcp_manifest()
        self.assertEqual(manifest["write_tools"], [])
        self.assertEqual(manifest["automatic_external_action_authority"], 0)
        self.assertGreaterEqual(len(manifest["tools"]), 5)

    def test_a2a_card_has_no_credentials_or_push(self) -> None:
        card = build_a2a_agent_card()
        self.assertFalse(card["capabilities"]["pushNotifications"])
        self.assertEqual(card["security"], [])
        self.assertIn("Reference local read-only", card["authentication_boundary"])

    def test_openapi_is_loopback_and_get_only(self) -> None:
        spec = build_openapi()
        self.assertEqual(spec["servers"][0]["url"], "http://127.0.0.1:8796")
        for operations in spec["paths"].values():
            self.assertEqual(set(operations), {"get"})

    def test_non_loopback_rejected(self) -> None:
        with self.assertRaises(ValueError):
            ensure_loopback("0.0.0.0")

    def test_cli_doctor(self) -> None:
        buffer = io.StringIO()
        old = sys.stdout
        try:
            sys.stdout = buffer
            rc = main(["doctor"])
        finally:
            sys.stdout = old
        self.assertEqual(rc, 0)
        payload = json.loads(buffer.getvalue())
        self.assertEqual(payload["automatic_external_action_authority"], 0)
        self.assertTrue(payload["stdlib_only_core"])

    def test_cli_radar_limit(self) -> None:
        out, bundle = demo_paths()
        buffer = io.StringIO()
        old = sys.stdout
        try:
            sys.stdout = buffer
            rc = main(["radar", "--bundle", str(bundle), "--limit", "3"])
        finally:
            sys.stdout = old
        self.assertEqual(rc, 0)
        payload = json.loads(buffer.getvalue())
        self.assertEqual(len(payload["records"]), 3)

    def test_mcp_stdio_tools_list_and_call(self) -> None:
        out, _ = demo_paths()
        env = dict(os.environ)
        env["PYTHONPATH"] = str(SRC)
        requests = [
            {"jsonrpc": "2.0", "id": 1, "method": "tools/list", "params": {}},
            {"jsonrpc": "2.0", "id": 2, "method": "tools/call", "params": {"name": "opportunity.radar", "arguments": {"limit": 2}}},
        ]
        proc = subprocess.run(
            [sys.executable, "-m", "dikwp_institution95", "mcp", "--out", str(out)],
            input="\n".join(json.dumps(row) for row in requests) + "\n",
            text=True,
            capture_output=True,
            env=env,
            cwd=ROOT,
            timeout=10,
            check=False,
        )
        self.assertEqual(proc.returncode, 0, proc.stderr)
        lines = [json.loads(line) for line in proc.stdout.splitlines() if line.strip()]
        self.assertEqual(len(lines), 2)
        self.assertGreaterEqual(len(lines[0]["result"]["tools"]), 5)
        self.assertEqual(len(lines[1]["result"]["records"]), 2)

    def test_read_only_http_server(self) -> None:
        out, _ = demo_paths()
        sock = socket.socket()
        sock.bind(("127.0.0.1", 0))
        port = sock.getsockname()[1]
        sock.close()
        thread = threading.Thread(target=serve, args=(out, "127.0.0.1", port), daemon=True)
        thread.start()
        last_exc: Exception | None = None
        for _ in range(50):
            try:
                with urlopen(f"http://127.0.0.1:{port}/health", timeout=1) as response:
                    payload = json.loads(response.read().decode("utf-8"))
                self.assertTrue(payload["read_only"])
                self.assertEqual(payload["automatic_external_action_authority"], 0)
                break
            except Exception as exc:  # startup race only
                last_exc = exc
                time.sleep(0.02)
        else:
            self.fail(f"server did not start: {last_exc}")
        request = Request(f"http://127.0.0.1:{port}/bundle", data=b"{}", method="POST")
        with self.assertRaises(HTTPError) as ctx:
            urlopen(request, timeout=2)
        self.assertEqual(ctx.exception.code, 405)


if __name__ == "__main__":
    unittest.main()
