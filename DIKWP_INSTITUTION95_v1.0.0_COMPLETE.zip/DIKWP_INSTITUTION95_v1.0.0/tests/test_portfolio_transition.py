from __future__ import annotations

import unittest

from common import load
from dikwp_institution95.assets import build_asset_map
from dikwp_institution95.lineage import build_lineage
from dikwp_institution95.opportunities import build_opportunity_radar
from dikwp_institution95.portfolio import allocation_for_runway, build_portfolio
from dikwp_institution95.scenarios import build_scenario_ensemble
from dikwp_institution95.signals import build_signal_map
from dikwp_institution95.transition import build_institution_scorecard, build_transition_plan, operating_model_registry


class PortfolioTransitionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.owner = load("owner.json")
        cls.constraints = load("constraints.json")
        cls.asset_map = build_asset_map(load("assets.json")["assets"])
        cls.signal_map = build_signal_map(load("signals.json")["signals"])
        cls.scenarios = build_scenario_ensemble(cls.signal_map)
        cls.radar = build_opportunity_radar(load("opportunities.json")["opportunities"], asset_map=cls.asset_map, signal_map=cls.signal_map, scenario_ensemble=cls.scenarios, constraints=cls.constraints)
        cls.portfolio = build_portfolio(cls.radar, cls.constraints, cls.owner)
        cls.lineage = build_lineage(load("lineage.json"))
        cls.scorecard = build_institution_scorecard(cls.owner, cls.asset_map, cls.radar, cls.constraints, cls.lineage)
        cls.transition = build_transition_plan(cls.scorecard, cls.radar, cls.portfolio, cls.constraints)

    def test_critical_runway_prioritizes_cash(self):
        self.assertEqual(allocation_for_runway(4)["cash_engine"], 0.65)

    def test_long_runway_increases_options(self):
        self.assertGreater(allocation_for_runway(30)["strategic_option"], allocation_for_runway(8)["strategic_option"])

    def test_portfolio_sums_to_one(self):
        self.assertAlmostEqual(self.portfolio["portfolio_share_sum"], 1.0, places=5)

    def test_portfolio_has_cash_engine(self):
        self.assertTrue(any(row["bucket"] == "cash_engine" for row in self.portfolio["selected"]))

    def test_portfolio_has_compounding_asset(self):
        self.assertTrue(any(row["bucket"] == "compounding_asset" for row in self.portfolio["selected"]))

    def test_scorecard_is_not_person_score(self):
        self.assertIn("not a rating", self.scorecard["interpretation_boundary"])

    def test_current_model_agent_augmented(self):
        self.assertEqual(self.scorecard["current_operating_model"]["model_id"], "agent_augmented_institution")

    def test_next_model_protocol(self):
        self.assertEqual(self.scorecard["next_operating_model"]["model_id"], "protocol_exposed_institution")

    def test_transition_has_five_phases(self):
        self.assertEqual(len(self.transition["phases"]), 5)

    def test_transition_is_not_automatic(self):
        self.assertEqual(self.transition["automatic_transition_authority"], 0)

    def test_registry_order(self):
        thresholds = [row["threshold"] for row in operating_model_registry()]
        self.assertEqual(thresholds, sorted(thresholds))

    def test_unpaid_scope_trigger_exists(self):
        text = str(self.transition)
        self.assertIn("免费", text)


if __name__ == "__main__":
    unittest.main()
