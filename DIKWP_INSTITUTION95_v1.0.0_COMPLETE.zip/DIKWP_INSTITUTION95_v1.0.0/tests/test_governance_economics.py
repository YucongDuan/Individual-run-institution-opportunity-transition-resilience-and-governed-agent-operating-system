from __future__ import annotations

import unittest

from common import load
from dikwp_institution95.assets import build_asset_map
from dikwp_institution95.economics import build_economic_resilience
from dikwp_institution95.governance import (
    agent_role_registry,
    build_agent_mandates,
    build_ai_transparency_manifest,
    build_burden_firewall,
)
from dikwp_institution95.opportunities import build_opportunity_radar
from dikwp_institution95.scenarios import build_scenario_ensemble
from dikwp_institution95.signals import build_signal_map


class GovernanceEconomicsTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.owner = load("owner.json")
        cls.constraints = load("constraints.json")
        assets = build_asset_map(load("assets.json")["assets"])
        signals = build_signal_map(load("signals.json")["signals"])
        scenarios = build_scenario_ensemble(signals)
        cls.radar = build_opportunity_radar(load("opportunities.json")["opportunities"], asset_map=assets, signal_map=signals, scenario_ensemble=scenarios, constraints=cls.constraints)
        cls.mandates = build_agent_mandates(cls.owner, cls.constraints)
        cls.transparency = build_ai_transparency_manifest(cls.owner, cls.constraints)
        cls.firewall = build_burden_firewall(cls.owner, cls.constraints)
        cls.economics = build_economic_resilience(cls.constraints, cls.radar)

    def test_nine_agent_roles(self):
        self.assertEqual(len(agent_role_registry()), 9)

    def test_all_mandates_external_zero(self):
        self.assertTrue(all(row["external_action_authority"] == 0 for row in self.mandates["records"]))

    def test_all_mandates_payment_zero(self):
        self.assertTrue(all(row["payment_authority"] == 0 for row in self.mandates["records"]))

    def test_all_mandates_revocable(self):
        self.assertTrue(all(row["revocable"] for row in self.mandates["records"]))

    def test_transparency_notice_required(self):
        self.assertTrue(self.transparency["direct_interaction_notice"]["required"])

    def test_no_compliance_certificate(self):
        self.assertIsNone(self.transparency["automatic_compliance_certificate"])

    def test_firewall_blocks_unpaid_custom(self):
        ids = {row["rule_id"] for row in self.firewall["rules"]}
        self.assertIn("no_unpaid_custom_prototype", ids)

    def test_firewall_acknowledgement_not_authority(self):
        ids = {row["rule_id"] for row in self.firewall["rules"]}
        self.assertIn("acknowledgement_not_authorization", ids)

    def test_economic_runway_positive(self):
        self.assertGreater(self.economics["planning_assumptions"]["conservative_runway_months"], 0)

    def test_break_even_examples_exist(self):
        self.assertGreater(len(self.economics["break_even_examples"]), 0)

    def test_revenue_target_shares_sum(self):
        self.assertAlmostEqual(sum(row["target_share"] for row in self.economics["revenue_architecture"]), 1.0)

    def test_financial_boundary_present(self):
        self.assertIn("not statements", self.economics["boundary"])


if __name__ == "__main__":
    unittest.main()
