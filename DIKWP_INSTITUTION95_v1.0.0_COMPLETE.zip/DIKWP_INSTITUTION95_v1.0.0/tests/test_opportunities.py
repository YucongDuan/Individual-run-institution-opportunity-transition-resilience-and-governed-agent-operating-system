from __future__ import annotations

import copy
import unittest

from common import load
from dikwp_institution95.assets import build_asset_map
from dikwp_institution95.opportunities import build_opportunity_radar, score_opportunity
from dikwp_institution95.scenarios import build_scenario_ensemble
from dikwp_institution95.signals import build_signal_map


class OpportunityTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.asset_map = build_asset_map(load("assets.json")["assets"])
        cls.signal_map = build_signal_map(load("signals.json")["signals"])
        cls.scenarios = build_scenario_ensemble(cls.signal_map)
        cls.constraints = load("constraints.json")
        cls.templates = load("opportunities.json")["opportunities"]
        cls.radar = build_opportunity_radar(cls.templates, asset_map=cls.asset_map, signal_map=cls.signal_map, scenario_ensemble=cls.scenarios, constraints=cls.constraints)

    def test_radar_count(self):
        self.assertEqual(len(self.radar["records"]), len(self.templates))

    def test_top_opportunity_is_actionable(self):
        self.assertIn(self.radar["records"][0]["recommendation"], {"GO_NOW", "PAID_TEST"})

    def test_unpaid_custom_is_blocked(self):
        row = next(r for r in self.radar["records"] if r["opportunity_id"] == "unpaid-custom-lab")
        self.assertTrue(row["blocked"])
        self.assertEqual(row["recommendation"], "REJECT_OR_REDESIGN")

    def test_generic_content_rejected(self):
        row = next(r for r in self.radar["records"] if r["opportunity_id"] == "generic-content-agency")
        self.assertEqual(row["recommendation"], "REJECT_OR_REDESIGN")

    def test_individual_institution_go_now(self):
        row = next(r for r in self.radar["records"] if r["opportunity_id"] == "individual-institution-kit")
        self.assertEqual(row["recommendation"], "GO_NOW")

    def test_scores_sorted(self):
        scores = [r["strategic_score"] for r in self.radar["records"]]
        self.assertEqual(scores, sorted(scores, reverse=True))

    def test_relative_weights_sum(self):
        total = sum(r["relative_opportunity_weight"] for r in self.radar["records"])
        self.assertAlmostEqual(total, 1.0, places=5)

    def test_missing_required_fields_rejected(self):
        with self.assertRaises(ValueError):
            score_opportunity({}, asset_records=[], signal_records=[], scenario_records=[], constraints={})

    def test_rights_block_can_prevent_selection(self):
        assets = copy.deepcopy(self.asset_map["records"])
        for asset in assets:
            asset["rights_status"] = "blocked"
            asset["rights_multiplier"] = 0
        row = score_opportunity(self.templates[0], asset_records=assets, signal_records=self.signal_map["records"], scenario_records=self.scenarios["records"], constraints=self.constraints)
        self.assertTrue(row["blocked"])

    def test_claim_boundary_present(self):
        self.assertIn("not a revenue forecast", self.radar["records"][0]["claim_boundary"])


if __name__ == "__main__":
    unittest.main()
