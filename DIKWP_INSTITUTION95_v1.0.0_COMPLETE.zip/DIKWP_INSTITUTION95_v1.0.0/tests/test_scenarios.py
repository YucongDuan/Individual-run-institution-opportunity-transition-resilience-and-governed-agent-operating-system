from __future__ import annotations

import unittest

from common import load
from dikwp_institution95.scenarios import build_scenario_ensemble, scenario_registry
from dikwp_institution95.signals import build_signal_map


class ScenarioTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.ensemble = build_scenario_ensemble(build_signal_map(load("signals.json")["signals"]))

    def test_registry_has_seven_models(self):
        self.assertEqual(len(scenario_registry()), 7)

    def test_weights_sum_to_one(self):
        self.assertAlmostEqual(sum(r["stress_weight"] for r in self.ensemble["records"]), 1.0, places=5)

    def test_models_are_unique(self):
        ids = [r["scenario_id"] for r in self.ensemble["records"]]
        self.assertEqual(len(ids), len(set(ids)))

    def test_agent_protocol_receives_support(self):
        record = next(r for r in self.ensemble["records"] if r["scenario_id"] == "agent_protocol_economy")
        self.assertGreater(len(record["signal_support"]), 0)

    def test_boundary_denies_forecast(self):
        self.assertIn("not calibrated", self.ensemble["interpretation_boundary"].lower())

    def test_retirement_rule_present(self):
        self.assertTrue(self.ensemble["retirement_rule"])


if __name__ == "__main__":
    unittest.main()
