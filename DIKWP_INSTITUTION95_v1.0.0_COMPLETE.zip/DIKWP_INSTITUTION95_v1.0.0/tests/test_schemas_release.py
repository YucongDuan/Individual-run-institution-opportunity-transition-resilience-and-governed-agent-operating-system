from __future__ import annotations

import json
from pathlib import Path
import unittest

from common import ROOT, demo_paths


class SchemaReleaseTests(unittest.TestCase):
    def test_all_schemas_parse(self) -> None:
        files = sorted((ROOT / "schemas").glob("*.json"))
        self.assertEqual(len(files), 9)
        for path in files:
            schema = json.loads(path.read_text(encoding="utf-8"))
            self.assertEqual(schema.get("$schema"), "https://json-schema.org/draft/2020-12/schema")
            self.assertIn("type", schema)

    def test_bundle_schema_declares_zero_authority(self) -> None:
        schema = json.loads((ROOT / "schemas" / "institution-bundle.schema.json").read_text(encoding="utf-8"))
        text = json.dumps(schema, ensure_ascii=False)
        self.assertIn("automatic_external_action_authority", text)

    def test_demo_outputs_are_json_valid(self) -> None:
        out, _ = demo_paths()
        json_files = list(out.glob("*.json"))
        self.assertGreaterEqual(len(json_files), 18)
        for path in json_files:
            json.loads(path.read_text(encoding="utf-8"))

    def test_dashboard_is_self_contained(self) -> None:
        out, _ = demo_paths()
        html = (out / "dashboard.html").read_text(encoding="utf-8")
        self.assertIn("DIKWP-INSTITUTION95", html)
        self.assertNotIn("<script src=", html.lower())
        self.assertNotIn("<link rel=", html.lower())

    def test_manifest_tracks_demo_validation_but_excludes_itself(self) -> None:
        out, _ = demo_paths()
        manifest = json.loads((out / "MANIFEST.json").read_text(encoding="utf-8"))
        paths = {row["path"] for row in manifest["files"]}
        self.assertNotIn("MANIFEST.json", paths)
        self.assertIn("DEMO_VALIDATION.json", paths)


if __name__ == "__main__":
    unittest.main()
