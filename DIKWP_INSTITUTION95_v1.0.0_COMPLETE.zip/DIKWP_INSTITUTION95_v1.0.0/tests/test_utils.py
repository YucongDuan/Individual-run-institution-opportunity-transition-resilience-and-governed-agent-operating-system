from __future__ import annotations

import unittest

from common import ROOT  # noqa: F401
from dikwp_institution95.utils import (
    canonical_json,
    clamp,
    lexical_tags,
    normalize_weights,
    overlap_score,
    sha256_obj,
    stable_id,
    weighted_mean,
)


class UtilsTests(unittest.TestCase):
    def test_canonical_json_key_order(self):
        self.assertEqual(canonical_json({"b": 1, "a": 2}), canonical_json({"a": 2, "b": 1}))

    def test_sha256_obj_deterministic(self):
        self.assertEqual(sha256_obj({"x": [1, 2]}), sha256_obj({"x": [1, 2]}))

    def test_stable_id_prefix(self):
        self.assertTrue(stable_id("x", {"a": 1}).startswith("x-"))

    def test_clamp_low(self):
        self.assertEqual(clamp(-2), 0.0)

    def test_clamp_high(self):
        self.assertEqual(clamp(2), 1.0)

    def test_normalize_weights(self):
        result = normalize_weights({"a": 2, "b": 1})
        self.assertAlmostEqual(sum(result.values()), 1.0)
        self.assertGreater(result["a"], result["b"])

    def test_normalize_zero_weights(self):
        result = normalize_weights({"a": 0, "b": 0})
        self.assertAlmostEqual(result["a"], 0.5)

    def test_lexical_tags(self):
        self.assertEqual(lexical_tags(["AI", "MCP/A2A"]), {"ai", "mcp", "a2a"})

    def test_overlap_score(self):
        self.assertAlmostEqual(overlap_score(["a", "b"], ["b", "c"]), 0.5)

    def test_weighted_mean(self):
        self.assertAlmostEqual(weighted_mean([(1, 3), (0, 1)]), 0.75)


if __name__ == "__main__":
    unittest.main()
