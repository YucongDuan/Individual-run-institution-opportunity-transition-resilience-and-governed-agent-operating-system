# Security Policy

## Reference security posture

- Python-standard-library core.
- Deterministic local compilation.
- Loopback-only HTTP server.
- Read-only API and MCP reference tools.
- Zero automatic authority for external actions, payments, identity use or self-modification.
- SHA-256 output manifest and tamper verification.

## Reporting

Report vulnerabilities through a private channel controlled by the deployment owner. Do not include private client data in public issues.

## Deployment boundary

This repository is not a production identity, payment, legal-compliance or multi-tenant security system. Production use requires authentication, authorization, secrets management, encryption, logging, backup, incident response, privacy review and jurisdiction-specific legal assessment.
